﻿using Newtonsoft.Json;
using project_class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Services;

namespace SCM_Sinotrade_Apply.Controllers
{
    public class API_Contract1Controller : Controller
    {
        //Log 分隔字串
        public string SetSplit = ConfigurationManager.AppSettings["LogSplit"];

        #region === 檢核會員申請資料 ===
        /// <summary>
        /// 檢核會員申請資料
        /// </summary>
        /// <param name="Str_Prod">行銷代碼 - 專案代碼</param>
        /// <param name="Str_Web">行銷代碼 - 網頁來源代碼</param>
        /// <param name="Str_IDNO">身分證字號</param>
        /// <param name="Str_PW">密碼</param>      
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult GetResult(string Str_DirType, string Str_Prod, string Str_Web, string Str_IDNO, string Str_PW)
        {           

            #region ::: 判斷是否為系統維護中 :::
            string Str_Maintain = Maintain.StopService(Str_IDNO);
            if (Str_Maintain != "")
            {
                var M_Obj = new JSON_Object();
                M_Obj.Status = "N";
                M_Obj.MSG = Str_Maintain;
                M_Obj.URL = "";
                return Json(M_Obj);
            }
            #endregion

            #region ::: SQLInjection :::
            string tmp_Dirtype = SQLInjection.SetValue(Str_DirType);
            string tmp_Prod = SQLInjection.SetValue(Str_Prod);
            string tmp_Web = SQLInjection.SetValue(Str_Web);
            string tmp_IDNO = SQLInjection.SetValue(Str_IDNO);
            string tmp_PW = Str_PW;
            #endregion

            #region ::: 參數 :::
            //Log 分隔字串
            string SetSplit = ConfigurationManager.AppSettings["LogSplit"].ToString();

            //Log 字串
            StringBuilder Str_Log = new StringBuilder();

            //try{}catch(){}錯誤訊息
            string Str_Exception = "";

            string Str_FlowState = "";//檢核點結果

            string Str_Status = "N";    //(Y)成功、(N)失敗
            string Str_MSG = "";        //回傳訊息
            string Str_URL = "";        //轉址URL

            //Client IP
            string Str_IP = LogClass.GetUserIP();

            string Str_SN = string.Empty;

            #endregion

            #region 1.【bl_Para】檢核 必要參數是否為空值

            //(false)空值、(true)非空值
            bool bl_Para = false;

            if (Str_IDNO != "" && Str_PW != "")
            {
                bl_Para = true;
            }

            #endregion

            #region 2.【bl_SQLInjection】檢核 是否含非法字元

            //(false)含非法字元、(true)正常字串
            bool bl_SQLInjection = false;

            if (Str_Prod == tmp_Prod &&
                Str_Web == tmp_Web &&
                Str_IDNO == tmp_IDNO)
            {
                bl_SQLInjection = true;
            }

            #endregion          

            #region 檢核錯誤訊息

            if (bl_Para == false)
            {
                Str_MSG = "傳遞參數含有空值";
            }
            else if (bl_SQLInjection == false)
            {
                Str_MSG = "參數含非法字元";
            }
                     

            #region :::: Write Log ::::

            Str_Log = new StringBuilder();
            Str_Log.Append("<START>");
            Str_Log.Append("功能 = 1.訂閱服務" + SetSplit);
            Str_Log.Append("程式 = API_Contract1Controller.cs/GetResult" + SetSplit);
            //============================================================================
            Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
            Str_Log.Append("Str_DirType = " + Str_DirType + SetSplit);
            Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
            Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
            //============================================================================
            Str_Log.Append("傳遞參數含有空值 = " + bl_Para + SetSplit);
            Str_Log.Append("參數含非法字元 = " + bl_SQLInjection + SetSplit);           
            Str_Log.Append("Str_MSG = " + Str_MSG);
            LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), "");

            #endregion

            #endregion

            try
            {

                if (Str_MSG == "")
                {
                    if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
                    {
                        Str_SN = "1";
                        Str_IDNO = "AKIUJYHTGR";
                        //測試
                        AddCookies(Str_DirType, Str_Prod, Str_Web, Str_SN, Str_IDNO);
                        LogClass.WriteLog("Contract1", "AddCookies");
                        Str_Status = "Y";
                        Str_URL = Url.Action("Contract2", "Apply");
                    }
                    else {
                        //檢查是否為會員                   
                        DataTable DT_CusData = CRM.GetCusData(Str_IDNO, Encryption.SetMD5(Str_PW));
                        if (DT_CusData.Rows.Count == 1)
                        {
                            //檢查商品 已購買不能再購買
                            DataTable DT_CUSCONT = CRM.GetDTCUSCONT(Str_IDNO);
                            if (DT_CUSCONT.Rows.Count == 0)
                            {
                                //判斷是否有在途名單 
                                bool? bl_CusApply = null;
                                DataTable DT_CusApply = CRM.GetApplyList(Str_IDNO);
                                if (DT_CusApply.Rows.Count > 0)
                                {
                                    for (int i = 0; i < DT_CusApply.Rows.Count; i++)
                                    {
                                        if (DT_CusApply.Rows[i]["CASE_TYPE"].ToString() == "N") //待審中
                                        {
                                            bl_CusApply = false;
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    bl_CusApply = true;
                                }

                                if (bl_CusApply.HasValue && bl_CusApply.Value)
                                {
                                    string Str_CopySN = DT_CusData.Rows[0]["SN"].ToString();
                                    //複製
                                    Str_SN = CopyApply(Str_Prod, Str_Web, Str_IDNO, DT_CusData);

                                    AddCookies(Str_DirType, Str_Prod, Str_Web, Str_SN, Str_IDNO);
                                    Str_Status = "Y";
                                    Str_URL = Url.Action("Contract2", "Apply");
                                }
                                else
                                {
                                    Str_Status = "N";
                                    Str_MSG = "抱歉！您已經申請過了，目前待審核中故無法再申購！";
                                    Str_URL = "";
                                }
                            }
                            else
                            {
                                Str_Status = "N";
                                Str_MSG = "付費商品僅能擇一訂閱";
                                Str_URL = "";
                            }

                        }
                        else
                        {
                            Str_Status = "N";
                            Str_MSG = "請先加入會員";
                            Str_URL = "";
                        }
                    }
                                             
                }
            }
            catch (Exception ex)
            {
                Str_Status = "N";
                Str_MSG = ConfigurationManager.AppSettings["WebSite_ERR_MSG"];
                Str_URL = Url.Action("error", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                Str_Exception = ex.ToString();
            }

            var J_Obj = new JSON_Object();
            J_Obj.Status = Str_Status;
            J_Obj.MSG = Str_MSG;
            J_Obj.URL = Str_URL;

            #region ::: Write Log :::

            Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 1.訂閱服務 回傳值" + SetSplit);
            Str_Log.Append("程式 = API_Contract1Controller.cs/GetResult" + SetSplit);
            Str_Log.Append("-----------------------------------------------------" + SetSplit);           
            Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
            Str_Log.Append("Str_SN = " + Str_SN + SetSplit);
            Str_Log.Append("-----------------------------------------------------" + SetSplit);
            Str_Log.Append("Str_URL = " + Str_URL + SetSplit);
            Str_Log.Append("Return = " + HttpUtility.HtmlEncode(JsonConvert.SerializeObject(J_Obj)));
            if (Str_Exception != "")
            {
                Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
            }

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), (((Str_Status != "Y" && Str_URL.Contains("erorr")) || Str_Exception != "") ? "1" : ""));
            }

            
            #endregion

            return Json(J_Obj);
        }
        #endregion

        #region === 欄位定義 ===
        public class JSON_Object
        {
            public string Status { get; set; }  //(Y)成功、(N)失敗
            public string MSG { get; set; }     //回傳訊息
            public string URL { get; set; }     //轉址URL
        }

        #endregion

        #region === 設定 Cookies ===
        /// <summary>
        /// 設定 Cookies
        /// </summary>
        /// <param name="Str_Prod">行銷代碼 - 專案代碼</param>
        /// <param name="Str_Web">行銷代碼 - 網頁來源代碼</param>       
        /// <param name="Str_SN">SpdOpenAct 系統編碼 ( SN )</param>
        /// <param name="Str_IDNO">身分證字號</param>       
        public void AddCookies(string Str_DirType, string Str_Prod, string Str_Web, string Str_SN, string Str_IDNO)
        {
            string Str_IP = LogClass.GetUserIP();   //使用者IP

            //時間
            DateTime NowDate = DateTime.Now;
            string Str_Date = NowDate.ToString("yyyy/MM/dd");

            //月日數值(ex: 7月5日 → 705)
            int MonthDay = Convert.ToInt16(NowDate.ToString("MMdd"));

            //將 ID 加密
            string Str_EnID = (Encryption.isEnID()) ? Encryption.myEncode(Str_IDNO, MonthDay) : Str_IDNO;

            //MD5 檢核碼
            string Str_Code = Encryption.SetMD5("OPA_x" + Str_SN + Str_Prod + Str_Web + Str_IDNO + Str_EnID + Str_Date + Str_IP + "x_APO");

            #region :::: Write Log ::: ( 設定 Cookies ) ===

            StringBuilder Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 設定 Cookies" + SetSplit);
            Str_Log.Append("程式 = API_Contract1Controller.cs/AddCookies" + SetSplit);            
            Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
            Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
            Str_Log.Append("Str_DirType = " + Str_DirType + SetSplit);
            Str_Log.Append("Str_EnID = " + Str_EnID + SetSplit);
            Str_Log.Append("Str_SN = " + Str_SN + SetSplit);
            Str_Log.Append("MonthDay = " + MonthDay + SetSplit);
            Str_Log.Append("Str_IP = " + Str_IP + SetSplit);
            Str_Log.Append("Str_Code = " + Str_Code);

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), "");
            }



            #endregion
            
            //====================//
            //=== 產生 Cookies ===//
            //====================//
            var Obj_UserInfo = new SetCookies.UserInfoCON();
            Obj_UserInfo.SN = Str_SN;
            Obj_UserInfo.Prod = Str_Prod;
            Obj_UserInfo.Web = Str_Web;
            Obj_UserInfo.DirType = Str_DirType;
            Obj_UserInfo.IDNO = Str_IDNO;
            Obj_UserInfo.EnID = Str_EnID;
            Obj_UserInfo.Date = Str_Date;
            Obj_UserInfo.IP = Str_IP;
            Obj_UserInfo.Code = Str_Code;
            SetCookies.SetDataCON(JsonConvert.SerializeObject(Obj_UserInfo));
           
        }
        #endregion

        #region === 複製申請資料 ===
        /// <summary>
        /// 複製申請資料
        /// </summary>          
        /// <returns></returns>
        public string CopyApply(string strProd, string strWeb,string Str_IDNO, DataTable DT_CusData)
        {
            string Str_Return = "Error";//Error為寫入失敗

            //try{}catch(){}錯誤訊息
            string Str_Exception = "";

            try
            {
                //UserAgent
                string Str_UserAgent = System.Web.HttpContext.Current.Request.UserAgent;
                string Str_Device = BrowserDevice.GetDevice(Str_UserAgent);
                string Str_Browser = BrowserDevice.GetBrowser();

                SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SCM"].ToString());
                StringBuilder Str_SQL = new StringBuilder();

                string Str_CopySN = DT_CusData.Rows[0]["SN"].ToString();

                Str_SQL.Append("INSERT INTO SCM_OpenAccounts(strProd,strWeb,IDNO,Phone,Name,Sex,Birthday_Year,Birthday_Month,Birthday_Day,EMail,Marry,Nation,Tel1,Tel2,Zip1,Addr1,Zip2,Addr2,Edut,Edut_1 ");
                Str_SQL.Append(",Occt,Occt_1,OffInst,OffCall,OffTel,OffFax,BillType ");
                Str_SQL.Append(",ServerIP,ClientIP,CreateDate ");
                Str_SQL.Append(",Nation_2,Nation_3,OffCall_Option,NationType,S_FB,S_LINE) ");
                Str_SQL.Append("SELECT @strProd AS strProd, @strWeb AS strWeb,IDNO,Phone,Name,Sex,Birthday_Year,Birthday_Month,Birthday_Day,EMail,Marry,Nation,Tel1,Tel2,Zip1,Addr1,Zip2,Addr2,Edut,Edut_1 ");
                Str_SQL.Append(",Occt,Occt_1,OffInst,OffCall,OffTel,OffFax,BillType ");
                Str_SQL.Append(",@ServerIP AS ServerIP,@ClientIP AS ClientIP, Getdate() AS CreateDate ");
                Str_SQL.Append(",Nation_2,Nation_3,OffCall_Option,NationType,S_FB,S_LINE ");
                Str_SQL.Append("FROM SCM_OpenAccounts WHERE SN = @SN ");
                Str_SQL.Append("SELECT @@IDENTITY AS SN; ");

                SqlCommand cmd = new SqlCommand(Str_SQL.ToString(), Conn);
                cmd.Parameters.AddWithValue("@strProd", strProd);
                cmd.Parameters.AddWithValue("@strWeb", strWeb);
                cmd.Parameters.AddWithValue("@ServerIP", ConfigurationManager.AppSettings["Server_IP"].ToString());
                cmd.Parameters.AddWithValue("@ClientIP", LogClass.GetUserIP());
                //cmd.Parameters.AddWithValue("@SN", Str_CopySN);


                cmd.Parameters.AddWithValue("@ServerIP", ConfigurationManager.AppSettings["Server_IP"].ToString());
                cmd.Parameters.AddWithValue("@ClientIP", LogClass.GetUserIP());

                string Str_Para = "";
                Str_Para = cmd.CommandText;
                foreach (SqlParameter p in cmd.Parameters)
                {
                    Str_Para = Str_Para.Replace(p.ParameterName, "'" + p.Value.ToString() + "'");
                }
                SqlDataAdapter Ada = new SqlDataAdapter(cmd);
                DataTable DT = new DataTable();
                Ada.Fill(DT);

                if (DT.Rows.Count > 0)
                {
                    Str_Return = DT.Rows[0]["SN"].ToString().Trim();
                }
            }
            catch (Exception ex)
            {
                Str_Return = "Error";
                Str_Exception = ex.ToString();
            }

            #region :::: Write Log :::

            StringBuilder Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 複製申請資料" + SetSplit);
            Str_Log.Append("程式 = API_ApplyContController.cs/CopyApply" + SetSplit);
            Str_Log.Append("strProd = " + strProd + SetSplit);
            Str_Log.Append("strWeb = " + strWeb + SetSplit);           
            Str_Log.Append("SN = " + Str_Return + SetSplit);
            if (Str_Exception != "")
            {
                Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
            }
            LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), ((Str_Exception != "") ? "1" : ""));
            #endregion

            return Str_Return;
        }


        #endregion

    }
}