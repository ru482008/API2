﻿using Newtonsoft.Json;
using project_class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Services;
using static project_class.SetCookies;

namespace SCM_Sinotrade_Apply.Controllers
{
    public class API_Contract2Controller : Controller
    {
        //Log 分隔字串
        public string SetSplit = ConfigurationManager.AppSettings["LogSplit"];

        [HttpPost]
        public JsonResult GetResult(string Str_CB_Check1)
        {           
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                var M_Obj = new JSON_Object();
                M_Obj.Status = "N";
                M_Obj.URL = Url.Action("Contract1", "Apply");
                return Json(M_Obj);
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;

            #endregion

            #region ::: 判斷是否為系統維護中 :::
            string Str_Maintain = Maintain.StopService(Str_IDNO);
            if (Str_Maintain != "")
            {
                var M_Obj = new JSON_Object();
                M_Obj.Status = "N";
                M_Obj.MSG = Str_Maintain;
                M_Obj.URL = "";
                return Json(M_Obj);
            }
            #endregion


            #region ::: SQLInjection :::
            string tmp_CB_Check1 = SQLInjection.SetValue(Str_CB_Check1);
            #endregion

            #region ::: 參數 :::
            //Log 分隔字串
            string SetSplit = ConfigurationManager.AppSettings["LogSplit"].ToString();

            //Log 字串
            StringBuilder Str_Log = new StringBuilder();

            //JSON 回應代碼 (Y)成功、(N)失敗
            string Str_Status = "N";

            //JSON 回應訊息
            string Str_MSG = "";

            //JSON 下一頁URL
            string Str_URL = "";

            //try{}catch(){}錯誤訊息
            string Str_Exception = "";

            #endregion

            #region 1.【bl_Para】檢核 必要參數是否為空值 

            //(false)空值、(true)非空值
            bool bl_Para = false;

            if (Str_CB_Check1 != "")
            {
                bl_Para = true;
            }

            #endregion

            #region 2.【bl_SQLInjection】檢核 是否含非法字元

            //(false)含非法字元、(true)正常字串
            bool bl_SQLInjection = false;

            if (Str_CB_Check1 == tmp_CB_Check1)
            {
                bl_SQLInjection = true;
            }

            #endregion

            #region 3.【CB_Check】檢核 是否勾選

            //(false)無勾選、(true)勾選
            bool bl_CB_Check1 = false;

            if (Str_CB_Check1 == "1")
            {
                bl_CB_Check1 = true;
            }

            #endregion

            #region 檢核錯誤訊息

            if (bl_Para == false)
            {
                Str_MSG = "傳遞參數含有空值";
            }
            else if (bl_SQLInjection == false)
            {
                Str_MSG = "參數含非法字元";
            }
            else if (bl_CB_Check1 == false)
            {
                Str_MSG = "請勾選確認項目";
            }

            #region :::: Write Log ::::

            Str_Log = new StringBuilder();            
            Str_Log.Append("功能 = 2.顧問商品購買聲明" + SetSplit);
            Str_Log.Append("程式 = API_Contract2Controller.cs/GetResult" + SetSplit);
            //============================================================================
            Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
            Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
            Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
            Str_Log.Append("Str_CB_Check1 = " + Str_CB_Check1 + SetSplit);
            //============================================================================
            Str_Log.Append("傳遞參數含有空值 = " + bl_Para + SetSplit);
            Str_Log.Append("參數含非法字元 = " + bl_SQLInjection + SetSplit);
            Str_Log.Append("檢核錯誤訊息 = " + bl_CB_Check1 + SetSplit);           
            Str_Log.Append("Str_MSG = " + Str_MSG);
            
            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), "");
            }
            #endregion
            #endregion



            try
            {
                if (Str_MSG == "")
                {
                    AddCookies(Obj_UserInfo, Str_CB_Check1);
                    Str_Status = "Y";
                    Str_URL = Url.Action("Contract3", "Apply");
                }
            }
            catch (Exception ex)
            {
                Str_Status = "N";
                Str_MSG = ConfigurationManager.AppSettings["WebSite_ERR_MSG"];
                Str_URL = Url.Action("error", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                Str_Exception = ex.ToString();
            }


            var J_Obj = new JSON_Object();
            J_Obj.Status = Str_Status;
            J_Obj.MSG = Str_MSG;
            J_Obj.URL = Str_URL;


            #region :::: Write Log :::: ( 顧問商品購買聲明 )

            Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 顧問商品購買聲明" + SetSplit);
            Str_Log.Append("程式 = API_Contract2Controller.cs/GetResult" + SetSplit);
            Str_Log.Append("Return = " + HttpUtility.HtmlEncode(JsonConvert.SerializeObject(J_Obj)));
            if (Str_Exception != "")
            {
                Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
            }
            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), ((Str_Status != "Y" || Str_Exception != "") ? "1" : ""));
            }
            

            #endregion

            return Json(J_Obj);
        }

        #region === 欄位定義 ===
        public class JSON_Object
        {
            public string Status { get; set; }  //(Y)成功、(N)失敗
            public string MSG { get; set; }     //回傳訊息
            public string URL { get; set; }     //轉址URL
        }

        #endregion

        #region === 設定 Cookies ===
        /// <summary>
        /// 設定 Cookies
        /// </summary>          
        public void AddCookies(UserInfoCON Obj_UserInfo,string CB_Check1)
        {                      
            Obj_UserInfo.SIGN_CON1 = CB_Check1;            
            SetCookies.SetDataCON(JsonConvert.SerializeObject(Obj_UserInfo));
        }
        #endregion
    }
}