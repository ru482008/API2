﻿using Newtonsoft.Json;
using project_class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Services;

namespace SCM_Sinotrade_Apply.Controllers
{
    public class API_Contract4Controller : Controller
    {
        //Log 分隔字串
        public string SetSplit = ConfigurationManager.AppSettings["LogSplit"];

        [HttpPost]
        public JsonResult GetResult(string Str_MAddr, string Str_EMail)
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                var M_Obj = new JSON_Object();
                M_Obj.Status = "N";
                M_Obj.URL = Url.Action("Contract1", "Apply");
                return Json(M_Obj);
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;

            #endregion

            #region ::: 判斷是否為系統維護中 :::
            string Str_Maintain = Maintain.StopService(Str_IDNO);
            if (Str_Maintain != "")
            {
                var M_Obj = new JSON_Object();
                M_Obj.Status = "N";
                M_Obj.MSG = Str_Maintain;
                M_Obj.URL = "";
                return Json(M_Obj);
            }
            #endregion


            #region ::: SQLInjection :::
            string tmp_MAddr = SQLInjection.SetValue(Str_MAddr);
            string tmp_EMail = SQLInjection.SetValue(Str_EMail);
            #endregion

            #region ::: 參數 :::
            //Log 分隔字串
            string SetSplit = ConfigurationManager.AppSettings["LogSplit"].ToString();

            //Log 字串
            StringBuilder Str_Log = new StringBuilder();

            //JSON 回應代碼 (Y)成功、(N)失敗
            string Str_Status = "N";

            //JSON 回應訊息
            string Str_MSG = "";

            //JSON 下一頁URL
            string Str_URL = "";

            //try{}catch(){}錯誤訊息
            string Str_Exception = "";

            #endregion

            #region 1.【bl_Para】檢核 必要參數是否為空值 

            //(false)空值、(true)非空值
            bool bl_Para = false;

            if (Str_MAddr != "" && Str_EMail != "")
            {
                bl_Para = true;
            }

            #endregion

            #region 2.【bl_SQLInjection】檢核 是否含非法字元

            //(false)含非法字元、(true)正常字串
            bool bl_SQLInjection = false;

            if (Str_MAddr == tmp_MAddr &&
                Str_EMail == tmp_EMail)
            {
                bl_SQLInjection = true;
            }

            #endregion
          

            #region 檢核錯誤訊息

            if (bl_Para == false)
            {
                Str_MSG = "傳遞參數含有空值";
            }
            else if (bl_SQLInjection == false)
            {
                Str_MSG = "參數含非法字元";
            }
            

            #region :::: Write Log ::::

            Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 4.填寫基本資料" + SetSplit);
            Str_Log.Append("程式 = API_Contract4Controller.cs/GetResult" + SetSplit);
            //============================================================================
            Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
            Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
            Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
            Str_Log.Append("Str_MAddr = " + Str_MAddr + SetSplit);
            Str_Log.Append("Str_EMail = " + Str_EMail + SetSplit);
            //============================================================================
            Str_Log.Append("傳遞參數含有空值 = " + bl_Para + SetSplit);
            Str_Log.Append("參數含非法字元 = " + bl_SQLInjection + SetSplit);            
            Str_Log.Append("Str_MSG = " + Str_MSG);

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), "");
            }
            #endregion
            #endregion

            try
            {
                if (Str_MSG == "")
                {
                    //修改基本資料                                      
                    // string Str_Return =UPDATEApply();

                    //if ("Error".Equals(Str_Return))
                    //{
                    //    Str_Status = "N";
                    //    Str_MSG = "系統忙線中，請稍後再試！";
                    //    Str_URL = "";
                    //}
                    //else
                    //{
                    //    Str_Status = "Y";
                    //    Str_URL = Url.Action("Contract4", "Apply");
                    //}

                    Str_Status = "Y";
                    Str_URL = Url.Action("Contract5", "Apply");

                }
            }
            catch (Exception ex)
            {
                Str_Status = "N";
                Str_MSG = ConfigurationManager.AppSettings["WebSite_ERR_MSG"];
                Str_URL = Url.Action("error", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                Str_Exception = ex.ToString();
            }


            var J_Obj = new JSON_Object();
            J_Obj.Status = Str_Status;
            J_Obj.MSG = Str_MSG;
            J_Obj.URL = Str_URL;


            #region :::: Write Log :::: ( 填寫基本資料 )

            Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 填寫基本資料" + SetSplit);
            Str_Log.Append("程式 = API_Contract4Controller.cs/GetResult" + SetSplit);
            Str_Log.Append("Return = " + HttpUtility.HtmlEncode(JsonConvert.SerializeObject(J_Obj)));
            if (Str_Exception != "")
            {
                Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
            }
            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), ((Str_Status != "Y" || Str_Exception != "") ? "1" : ""));
            }


            #endregion

            return Json(J_Obj);
        }

        #region === 欄位定義 ===
        public class JSON_Object
        {
            public string Status { get; set; }  //(Y)成功、(N)失敗
            public string MSG { get; set; }     //回傳訊息
            public string URL { get; set; }     //轉址URL
        }

        #endregion

        #region === 寫入基本資料 ===               

        /// <summary>
        /// 寫入申請資料
        /// </summary>
        /// <param name="Str_Prod">行銷代碼 - 專案代碼</param>
        /// <param name="Str_Web">行銷代碼 - 網頁來源代碼</param>
        /// <param name="Str_IP">Client IP</param>
        /// <param name="Str_IDNO">身分證字號</param>
        /// <param name="Str_Year">生日-年</param>
        /// <param name="Str_Month">生日-月</param>
        /// <param name="Str_Day">生日-日</param>
        /// <param name="bl_Guideline">(true)是、(false)否前需往引導頁</param>
        /// <returns></returns>
        //public string NewApply(string Str_Prod, string Str_Web, string Str_IP, string Str_IDNO, string Str_Year, string Str_Month, string Str_Day, bool bl_Guideline, string Str_S_ADNO, string Str_S_Broker)      
        public string UPDATEApply(string tmp_IDNO, string tmp_SN, string tmp_MAddr, string tmp_EMail, string tmp_Tel2, string tmp_Marry, string tmp_Edut
            , string tmp_Career, string tmp_Career_Other, string tmp_OffInst, string tmp_OffCall, string tmp_OffCall_Other, string tmp_Tel3, string tmp_LINE)
        {
            string Str_Return = "Error";//Error為寫入失敗

            //try{}catch(){}錯誤訊息
            string Str_Exception = string.Empty;
            string Str_InsertSN = string.Empty;


            try
            {
                string Str_Para = "";
                SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SCM"].ToString());
                StringBuilder Str_SQL_Update = new StringBuilder();

                Str_SQL_Update.Append("UPDATE SCM_OpenAccounts ");
                Str_SQL_Update.Append("SET ");
                //Str_SQL_Update.Append("strProd = @strProd,");
                //Str_SQL_Update.Append("strWeb = @strWeb,");
                //Str_SQL_Update.Append("Name = @Name, ");//姓名
                Str_SQL_Update.Append("ToCRM = 0 ,");
                //Str_SQL_Update.Append("Phone = @Phone, ");//性別
                //Str_SQL_Update.Append("Sex = @Sex, ");//手機
                //Str_SQL_Update.Append("Birthday_Year = @Birthday_Year, ");//出生日期
                //Str_SQL_Update.Append("Birthday_Month = @Birthday_Month, ");
                //Str_SQL_Update.Append("Birthday_Day = @Birthday_Day, ");
                Str_SQL_Update.Append("EMail = @EMail, ");//電子信箱
                Str_SQL_Update.Append("Marry = @Marry, ");//婚姻狀況
                //Str_SQL_Update.Append("Tel1 = @Tel1, ");//戶籍電話
                Str_SQL_Update.Append("Tel2 = @Tel2, ");//聯絡電話
                //Str_SQL_Update.Append("Zip1 = @Zip1, ");//戶籍地址區號(暫時無使用)
                //Str_SQL_Update.Append("Zip2 = @Zip2, ");//通訊地址區號(其它)
                //Str_SQL_Update.Append("Addr1 = @Addr1, ");//戶籍地址
                Str_SQL_Update.Append("Addr2 = @Addr2, ");//通訊地址(其它)
                Str_SQL_Update.Append("Edut = @Education, ");//教育程度
                //Str_SQL_Update.Append("Edut_1 = @Education_Other, ");//教育程度(其它)
                Str_SQL_Update.Append("Occt = @Occt, ");//職務類別
                Str_SQL_Update.Append("Occt_1 = @Occt_1, ");//職務類別(其它)
                Str_SQL_Update.Append("OffInst = @OffInst, ");//服務機構
                Str_SQL_Update.Append("OffCall = @OffCall, ");//擔任職務
                Str_SQL_Update.Append("OffTel = @OffTel, ");//公司電話
                //Str_SQL_Update.Append("OffFax = @OffFax, ");//公司傳真號碼
                Str_SQL_Update.Append("BillType = @BillType, ");//契約收執方式    
                Str_SQL_Update.Append("PayKind = @PayKind, ");
                //Str_SQL_Update.Append("KYC_Flag = @KYC_Flag, ");
                //Str_SQL_Update.Append("CusCont = @CusCont, ");
                Str_SQL_Update.Append("ServerIP = @ServerIP, ");
                Str_SQL_Update.Append("ClientIP = @ClientIP, ");
                Str_SQL_Update.Append("UpdateDate = GETDATE(), ");
                //20210826
                //Str_SQL_Update.Append("NationType = @NationType, ");
                //Str_SQL_Update.Append("Nation_2 = @Nation_2, ");
                //Str_SQL_Update.Append("Nation_3 = @Nation_3, ");
                Str_SQL_Update.Append("OffCall_Option = @OffCall_Option,");
                Str_SQL_Update.Append("S_LINE = @S_LINE ");

                Str_SQL_Update.Append("WHERE SN = @SN ");
                Str_SQL_Update.Append("AND IDNO = @IDNO ");
                SqlCommand cmd_Update = new SqlCommand(Str_SQL_Update.ToString(), Conn);
                //cmd_Update.Parameters.AddWithValue("@strProd", tmp_Prod);
                //cmd_Update.Parameters.AddWithValue("@strWeb", tmp_Web);
                //cmd_Update.Parameters.AddWithValue("@Name", tmp_UserName);//姓名
                //cmd_Update.Parameters.AddWithValue("@Sex", tmp_Sex);//性別
                //cmd_Update.Parameters.AddWithValue("@Phone", tmp_Phone);
                //cmd_Update.Parameters.AddWithValue("@Birthday_Year", tmp_Birth.Substring(0, 4));
                //cmd_Update.Parameters.AddWithValue("@Birthday_Month", tmp_Birth.Substring(4, 2));
                //cmd_Update.Parameters.AddWithValue("@Birthday_Day", tmp_Birth.Substring(6, 2));
                cmd_Update.Parameters.AddWithValue("@EMail", tmp_EMail);//電子信箱
                cmd_Update.Parameters.AddWithValue("@Marry", tmp_Marry);//婚姻狀況
                //cmd_Update.Parameters.AddWithValue("@Tel1", tmp_Tel1);//戶籍電話
                cmd_Update.Parameters.AddWithValue("@Tel2", tmp_Tel2);//聯絡電話
                cmd_Update.Parameters.AddWithValue("@Education", tmp_Edut);//教育程度
                //cmd_Update.Parameters.AddWithValue("@Education_Other", ((Str_Edut == "0") ? Str_Edut_Other : ""));//教育程度(其它)
                cmd_Update.Parameters.AddWithValue("@Occt", tmp_Career);//職務類別
                cmd_Update.Parameters.AddWithValue("@Occt_1", ((tmp_Career == "Z4" || tmp_Career == "Z6" || tmp_Career == "Z9") ? tmp_Career_Other : ""));//職務類別
                cmd_Update.Parameters.AddWithValue("@OffInst", tmp_OffInst);//服務機構
                cmd_Update.Parameters.AddWithValue("@OffCall", tmp_OffCall_Other);//擔任職務
                cmd_Update.Parameters.AddWithValue("@OffTel", tmp_Tel3);//公司電話
                //cmd_Update.Parameters.AddWithValue("@OffFax", Str_Fax);//公司傳真號碼
                //cmd_Update.Parameters.AddWithValue("@Zip1", tmp_Rzip);//戶籍地址區號(暫時無使用)
                //cmd_Update.Parameters.AddWithValue("@Zip2", tmp_Mzip);//通訊地址區號(其它)
                //cmd_Update.Parameters.AddWithValue("@Addr1", Str_RAddr);//戶籍地址
                cmd_Update.Parameters.AddWithValue("@Addr2", tmp_MAddr);//通訊地址(其它)
                cmd_Update.Parameters.AddWithValue("@BillType", "2");//契約收執方式
                cmd_Update.Parameters.AddWithValue("@PayKind", "");//付款方式
                //cmd_Update.Parameters.AddWithValue("@KYC_Flag", tmp_KYC_Flag);//KYC註記
                //cmd_Update.Parameters.AddWithValue("@CusCont", tmp_CusCont);//購買策略
                cmd_Update.Parameters.AddWithValue("@ServerIP", ConfigurationManager.AppSettings["Server_IP"].ToString());
                cmd_Update.Parameters.AddWithValue("@ClientIP", LogClass.GetUserIP());
                //20210826
                //cmd_Update.Parameters.AddWithValue("@NationType", tmp_NationType);//國籍
                //cmd_Update.Parameters.AddWithValue("@Nation_2", Str_Nation_2);//國籍
                //cmd_Update.Parameters.AddWithValue("@Nation_3", Str_Nation_3);//國籍
                cmd_Update.Parameters.AddWithValue("@OffCall_Option", tmp_OffCall);//擔任職務
                cmd_Update.Parameters.AddWithValue("@S_LINE", tmp_LINE);//社群用戶帳號

                cmd_Update.Parameters.AddWithValue("@SN", tmp_SN);
                cmd_Update.Parameters.AddWithValue("@IDNO", tmp_IDNO);
                //Command to String
                Str_Para = cmd_Update.CommandText;
                foreach (SqlParameter p in cmd_Update.Parameters)
                {
                    Str_Para = Str_Para.Replace(p.ParameterName, "'" + p.Value.ToString() + "'");
                }
                SqlDataAdapter Ada_Update = new SqlDataAdapter(cmd_Update);
                DataTable DT_Update = new DataTable();
                Ada_Update.Fill(DT_Update);

                Str_Return = tmp_SN;
            }
            catch (Exception ex)
            {
                Str_Return = "Error";
                Str_Exception = ex.ToString();
            }

            #region :::: Write Log :::

            StringBuilder Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 寫入申請資料" + SetSplit);
            Str_Log.Append("程式 = API_IndexController.cs/NewApply" + SetSplit);
            //Str_Log.Append("strProd = " + Str_Prod + SetSplit);
            //Str_Log.Append("strWeb = " + Str_Web + SetSplit);
            Str_Log.Append("SN = " + Str_Return + SetSplit);
            if (Str_Exception != "")
            {
                Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
            }
            LogClass.SCM_OpenAccounts_Log(tmp_IDNO, Str_Log.ToString(), ((Str_Exception != "") ? "1" : ""));
            #endregion

            return Str_Return;
        }
        #endregion
    }
}