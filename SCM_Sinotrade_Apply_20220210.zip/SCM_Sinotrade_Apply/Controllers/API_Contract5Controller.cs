﻿using Newtonsoft.Json;
using project_class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Services;

namespace SCM_Sinotrade_Apply.Controllers
{
    public class API_Contract5Controller : Controller
    {
        //Log 分隔字串
        public string SetSplit = ConfigurationManager.AppSettings["LogSplit"];

        [HttpPost]
        public JsonResult GetResult(string Str_SIGN_P2)
        {
           
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                var M_Obj = new JSON_Object();
                M_Obj.Status = "N";
                M_Obj.URL = Url.Action("Contract1", "Apply");
                return Json(M_Obj);
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_DirType = Obj_UserInfo.DirType;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;

            #endregion

            #region ::: 判斷是否為系統維護中 :::
            string Str_Maintain = Maintain.StopService(Str_IDNO);
            if (Str_Maintain != "")
            {
                var M_Obj = new JSON_Object();
                M_Obj.Status = "N";
                M_Obj.MSG = Str_Maintain;
                M_Obj.URL = "";
                return Json(M_Obj);
            }
            #endregion


            #region ::: SQLInjection :::
            string tmp_SIGN_P2 = SQLInjection.SetValue(Str_SIGN_P2);
            #endregion
          
            #region ::: 參數 :::
            //Log 分隔字串
            string SetSplit = ConfigurationManager.AppSettings["LogSplit"].ToString();

            //Log 字串
            StringBuilder Str_Log = new StringBuilder();

            //JSON 回應代碼 (Y)成功、(N)失敗
            string Str_Status = "N";

            //JSON 回應訊息
            string Str_MSG = "";

            //JSON 下一頁URL
            string Str_URL = "";

            //try{}catch(){}錯誤訊息
            string Str_Exception = "";

            #endregion

            #region 1.【bl_Para】檢核 必要參數是否為空值 

            //(false)空值、(true)非空值
            bool bl_Para = false;

            if (Str_SIGN_P2 != "" )
            {
                bl_Para = true;
            }

            #endregion

            #region 2.【bl_SQLInjection】檢核 是否含非法字元

            //(false)含非法字元、(true)正常字串
            bool bl_SQLInjection = false;

            if (Str_SIGN_P2 == tmp_SIGN_P2)
            {
                bl_SQLInjection = true;
            }

            #endregion

            #region 3.【CB_Check】檢核 是否勾選

            //(false)無勾選、(true)勾選
            bool bl_SIGN_P2 = false;

            if (Str_SIGN_P2 == "1")
            {
                bl_SIGN_P2 = true;
            }

            #endregion


            #region 檢核錯誤訊息

            if (bl_Para == false)
            {
                Str_MSG = "傳遞參數含有空值";
            }
            else if (bl_SQLInjection == false)
            {
                Str_MSG = "參數含非法字元";
            }
            else if (bl_SIGN_P2 == false)
            {
                Str_MSG = "請勾選證券投資顧問委任契約";
            }


            #region :::: Write Log ::::

            Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 5.契約簽署" + SetSplit);
            Str_Log.Append("程式 = API_Contract5Controller.cs/GetResult" + SetSplit);
            //============================================================================
            Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
            Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
            Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
            Str_Log.Append("Str_SIGN_P2 = " + Str_SIGN_P2 + SetSplit);            
            //============================================================================
            Str_Log.Append("傳遞參數含有空值 = " + bl_Para + SetSplit);
            Str_Log.Append("參數含非法字元 = " + bl_SQLInjection + SetSplit);
            Str_Log.Append("Str_MSG = " + Str_MSG);

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), "");
            }
            #endregion
            #endregion


            //判斷是否有在途名單            
            DataTable DT_CusApply = CRM.GetApplyList(Str_IDNO);
            if (DT_CusApply.Rows.Count > 0)
            {
                for (int i = 0; i < DT_CusApply.Rows.Count; i++)
                {
                    if (DT_CusApply.Rows[i]["CASE_TYPE"].ToString() == "N")
                    {
                        Str_MSG = "新申請失敗，" + DT_CusApply.Rows[i]["APPLY_TYPE_NM"].ToString() + "待審核中故無法再申購!";                       
                    }
                }
            }

            try
            {
                if (Str_MSG == "")
                {
                    //申請完成，資料寫至CRM
                    Str_MSG = SaveData_CRM("申請資訊上傳CRM", Str_IDNO, Str_SN,"","","");
                    if (Str_MSG == "")
                    {
                        //更新申請資訊
                        Str_MSG = SaveData_SCM("申請資訊更新", "1", Str_IDNO, Str_SN, "");
                        if (Str_MSG == "")
                        {
                            //轉址至申請成功頁
                            //type 11 PC 		SCM：證投交易
                            //type 12 豐管家 	SCM：證投交易

                            //傳遞參數
                            string Str_URL_Para = "";
                            //if (Platform == "APP")
                            //{
                            //    Str_URL_Para = "?type=12&md=" + md;
                            //}
                            //else
                            //{
                            //    //身份證字號
                            //    string Str_UserID = SQLInjection.SetValue(hf_UserID.Text);
                            //    Str_URL_Para = "?type=11&md=" + Encryption.mdEncode(Str_UserID);
                            //}

                            //登出PDF
                            //string[] aryLogout = QR_PDF.Logout(Str_IDNO, StrSession, ApplyType);

                            //2019/03/14寄email給客戶
                            StringBuilder Str_Body = new StringBuilder();
                            string Str_Title = "";

                            string Str_Body_Text_1 = "";
                            string Str_Body_Text_2 = "";
                            string Str_Body_Text_3 = "";

                            Str_Body.Append("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"><title>永豐投顧委任契約申請通知</title></head> ");
                            Str_Body.Append("	<body><center><table  style=\"margin:0 auto; width:640px; background:#FFF\" border=\"0\"  cellspacing=\"0\">");
                            Str_Body.Append("  <tr><td ><a href=\"#\" target=\"_blank\"><img src=\"https://scm.sinotrade.com.tw/SCM_Sinotrade/images/Result/edm_head.jpg\" alt=\"永豐投顧委任契約申請通知\" border=\"0\" ></a></td></tr>");
                            Str_Body.Append("  <tr><td align=\"center\" bgcolor=\"#FFFFFF\" ><table width=\"500\">  <tr><td>&nbsp;</td></tr><tr><td style=\"font-family:微軟正黑體; font-size:18px; line-height:1.6; font-weight:bold;\">親愛的客戶，您好：</td></tr>");

                            //新會員開戶完成發E-MAIL
                            Str_Title = "永豐投顧委任契約申請通知";                            
                            
                                Str_Body_Text_1 = @"感謝您訂閱永豐投顧會員服務，我們將盡速審核您所提交文件!<br/><br/>
                                            提醒您!首次登入請於會員登入頁執行「首次啟用」設定會員專屬密碼，以享有專屬服務。<br/><br/>
                                            會員效期及契約，皆可登入「會員中心」查詢。<br/><br/>
                                            永豐投顧會員等級權益說明如下:<br/>
                                            【研報會員】<br/>
                                            每日報告投資快訊，盡在永豐投顧官方網站。<br/><br/>
                                            【白金/黑卡會員-專屬LINE群組】<br/>
                                            審核完成將另聯繫進入專屬群組，除了最新股市投資訊息還有專屬音頻，讓您盡享完整「投+顧」會員體驗。<br/><br/>
                                            在投資的旅程裡，希望我們的陪伴能提供您不同的投資體驗及學習!<br/>
                                            如有疑問，亦可洽永豐投顧客服專線02-2361-0868分機888。<br/>                           
                                            ";
                                Str_Body_Text_2 = "<br/>敬祝 投資順利!";
                                //進度查詢導址分流
                                Str_Body_Text_3 = "<a href='" + ConfigurationManager.AppSettings["WebSite_URL"].ToString() + "/process/ForgetPA01.aspx?strProd=0018&strWeb=0002&Type=Query&strFunc=SetPWD'><img src='https://scm.sinotrade.com.tw/SCM_Sinotrade/Images/Result/btn_trust_03.png' alt='確認' /></a>";

                                Str_Body.Append("<tr><td>&nbsp;</td></tr> <tr><td style=\"font-family:微軟正黑體; font-size:15px; line-height:1.6;\">" + Str_Body_Text_1 + "<br/></td></tr> ");
                                Str_Body.Append("<tr><td>&nbsp;</td></tr> <tr><td style=\"font-family:微軟正黑體; font-size:15px; line-height:1.6;\">" + Str_Body_Text_2 + "<br/></td></tr> ");

                                DataTable DT_SCM = CRM.GetDT_SCMData(Str_IDNO, Str_SN);
                                string Str_CusCont = "";
                                string Str_EMail = "";
                                
                                if (DT_SCM.Rows.Count > 0)
                                {
                                    //投顧會員項目清單顯示基本資料
                                    ViewBag.Name = DT_SCM.Rows[0]["Name"].ToString().Trim();       //姓名
                                    ViewBag.Phone = DT_SCM.Rows[0]["Phone"].ToString().Trim();     //電話
                                    Str_EMail = DT_SCM.Rows[0]["EMail"].ToString().Trim();     //E-mail

                                    Str_CusCont = DT_SCM.Rows[0]["CusCont"].ToString();
                                }
                                    DataTable DT_Cont = CRM.GetDT_ContData(Str_IDNO, Str_DirType, Str_CusCont);
                                if (DT_Cont.Rows.Count > 0)
                                {
                                    //申購契約明細
                                    Str_Body.Append("<tr><td><table border=\"1\" cellspacing=\"0\" style=\"border-collapse:collapse; border-image:none;width:600px;border:1pt solid windowtext\">");
                                    Str_Body.Append("<tr><td width =\"60%\" style=\"font-family:微軟正黑體; font-size:15px; line-height:1.6\">契約名稱</td>");
                                    Str_Body.Append("<td width =\"40%\" style=\"font-family:微軟正黑體; font-size:15px; line-height:1.6\">效期</td>	</tr>");

                                    for (int i = 0; i < DT_Cont.Rows.Count; i++)
                                    {

                                        string Str_ContName = DT_Cont.Rows[i]["CONT_NAME"].ToString();
                                        string Str_ContItem = DT_Cont.Rows[i]["CONT_ITEM"].ToString();
                                        Str_Body.Append("<tr><td style=\"font-family:微軟正黑體; font-size:15px; line-height:1.6\"><span style=\"color:red\">" + Str_ContName + "</span></td>");
                                        Str_Body.Append("<td style=\"font-family:微軟正黑體; font-size:15px; line-height:1.6\"><span style=\"color:red\">" + Str_ContItem + "</span></td>	</tr>");

                                    }
                                    Str_Body.Append("</table></td></tr>");
                                }
                                Str_Body.Append("<tr><td colspan='2' >&nbsp;</td></tr> <tr><td colspan='2' style=\"font-family:微軟正黑體; font-size:15px; line-height:1.6;text-align: center; vertical-align: middle;\">" + Str_Body_Text_3 + "<br/></td></tr> ");
                                Str_Body.Append("  <tr><td colspan='2' ><a href=\"#\" target=\"_blank\"><img src=\"https://scm.sinotrade.com.tw/SCM_Sinotrade/images/Result/edm_footer.png\" alt=\"投顧會員申請提醒\" border=\"0\" ></a></td></tr>");
                                Str_Body.Append("    </table></center></body></html> ");
                            
                            //Send EMail
                            EMail.Send("", Str_IDNO, Str_EMail, Str_Title, Str_Body.ToString(), LogClass.GetUserIP());

                            Str_Status = "Y";
                            Str_URL = Url.Action("Contract6", "Apply");
                        }
                        else {
                            Str_MSG = "申購資訊已完成送出；但申請狀態更新失敗請洽客服。";
                        }
                        
                    }                    
                       
                }
            }
            catch (Exception ex)
            {
                Str_Status = "N";
                Str_MSG = ConfigurationManager.AppSettings["WebSite_ERR_MSG"];
                Str_URL = Url.Action("error", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                Str_Exception = ex.ToString();
            }


            var J_Obj = new JSON_Object();
            J_Obj.Status = Str_Status;
            J_Obj.MSG = Str_MSG;
            J_Obj.URL = Str_URL;


            #region :::: Write Log :::: ( 填寫基本資料 )

            Str_Log = new StringBuilder();
            Str_Log.Append("功能 = 契約簽署" + SetSplit);
            Str_Log.Append("程式 = API_Contract5Controller.cs/GetResult" + SetSplit);
            Str_Log.Append("Return = " + HttpUtility.HtmlEncode(JsonConvert.SerializeObject(J_Obj)));
            if (Str_Exception != "")
            {
                Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
            }
            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {
                LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), ((Str_Status != "Y" || Str_Exception != "") ? "1" : ""));
            }


            #endregion

            return Json(J_Obj);
        }

        #region === 欄位定義 ===
        public class JSON_Object
        {
            public string Status { get; set; }  //(Y)成功、(N)失敗
            public string MSG { get; set; }     //回傳訊息
            public string URL { get; set; }     //轉址URL
        }

        #endregion

        #region === 新增CRM資料  (本次新增的)    ===
        protected string SaveData_CRM(string str_Step,string Str_UserID,string Str_Edit_SN,string Str_DirType, string DocumentID,string ApplyType)
        {
            SqlConnection Conn_CRM = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_CRM"].ToString());
            //商品
            ApplyType = "P";
            string Str_Exception = string.Empty;                                //紀錄errlog
            string Str_Msg = "";               

            StringBuilder Str_SQL = new StringBuilder();
            StringBuilder Str_SQL_Exec = new StringBuilder();

            //新增資料
            if (!string.IsNullOrWhiteSpace(Str_UserID) && !string.IsNullOrWhiteSpace(Str_Edit_SN))
            {
                try
                {
                    DataTable DT = CRM.GetDT_SCMData(Str_UserID, Str_Edit_SN);
                    //有資料更新
                    if (DT.Rows.Count > 0)
                    {
                        //防止重覆送件
                        if (DT.Rows[0]["ToCRM"].ToString() == "1")
                        {
                            Str_Msg = "你已申請成功，請勿重新送件!!!!";
                        }
                        else
                        {

                            Str_SQL_Exec.Append("EXEC SP_OM_OA_MAIN_UPD ");
                            Str_SQL_Exec.Append("@SEQ_NO=0,@FUNC_TYPE='I', ");
                            Str_SQL_Exec.Append("@APPLY_DATE='" + DateTime.Now.ToString("yyyMMdd") + "',");
                            Str_SQL_Exec.Append("@SINO_NO='" + Str_Edit_SN + "',");
                            Str_SQL_Exec.Append("@CASE_NO='" + DocumentID + "',");
                            Str_SQL_Exec.Append("@FLOW_NO= 0,");
                            Str_SQL_Exec.Append("@PROD_ID ='" + DT.Rows[0]["strProd"].ToString() + "',");
                            Str_SQL_Exec.Append("@WEB_ID  ='" + DT.Rows[0]["strWeb"].ToString() + "',");
                            Str_SQL_Exec.Append("@DIR_TYPE  ='" + Str_DirType + "',");
                            Str_SQL_Exec.Append("@S_IDNO  ='" + Str_UserID + "',");
                            Str_SQL_Exec.Append("@S_NAME   =N'" + DT.Rows[0]["Name"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_SEX  ='" + DT.Rows[0]["Sex"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_BIRTH  ='" + DT.Rows[0]["Birthday_Year"].ToString() + DT.Rows[0]["Birthday_Month"].ToString() + DT.Rows[0]["Birthday_Day"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_KIND  ='2',");
                            Str_SQL_Exec.Append("@S_TYPE  ='Y',");      //是否開電子戶
                            Str_SQL_Exec.Append("@S_TEL1  ='" + DT.Rows[0]["Tel1"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_TEL2  ='" + DT.Rows[0]["Tel2"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_MOBLE ='" + DT.Rows[0]["Phone"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_EMAIL =N'" + DT.Rows[0]["EMail"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_ZIP1  ='" + DT.Rows[0]["Zip1"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_ADDR1  =N'" + DT.Rows[0]["Addr1"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_ZIP2  ='" + DT.Rows[0]["Zip2"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_ADDR2  =N'" + DT.Rows[0]["Addr2"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_MARRY ='" + DT.Rows[0]["Marry"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_EDUT ='" + DT.Rows[0]["Edut"].ToString() + "',");
                            Str_SQL_Exec.Append("@T_EDUT =N'" + DT.Rows[0]["Edut_1"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_OCCT ='" + DT.Rows[0]["Occt"].ToString() + "',");
                            Str_SQL_Exec.Append("@T_OCCT =N'" + DT.Rows[0]["Occt_1"].ToString() + "',");
                            Str_SQL_Exec.Append("@APPLY_TYPE ='" + ApplyType + "',");
                            //Str_SQL_Exec.Append("@PAY_KIND = '" + hf_PayKind.Value + "',");
                            //銷帳編號                            
                            //*Str_SQL_Exec.Append("@PAY_AMT_NO = '" + Encryption.GetPayAmtNo() + "',");
                            //*Str_SQL_Exec.Append("@PAY_TYPE = '" + ((Convert.ToDecimal(hf_ContAmt.Value) == 0) ? "Y" : "N") + "',");
                            Str_SQL_Exec.Append("@BILL_TYPE = '" + DT.Rows[0]["BillType"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_IP ='" + LogClass.GetUserIP() + "',");
                            Str_SQL_Exec.Append("@OFF_INST =N'" + DT.Rows[0]["OffInst"].ToString() + "',");
                            Str_SQL_Exec.Append("@OFF_FAX =N'" + DT.Rows[0]["OffFax"].ToString() + "',");
                            Str_SQL_Exec.Append("@OFF_CALL =N'" + DT.Rows[0]["OffCall"].ToString() + "',");
                            Str_SQL_Exec.Append("@OFF_TEL ='" + DT.Rows[0]["OffTel"].ToString() + "',");
                            Str_SQL_Exec.Append("@CONT_NO =N'" + DT.Rows[0]["CusCont"].ToString() + "',");
                            //20210924新增欄位
                            Str_SQL_Exec.Append("@S_NATION_TYPE =N'" + DT.Rows[0]["NationType"].ToString() + "',");
                            //Str_SQL_Exec.Append("@S_NATION_2 =N'" + DT.Rows[0]["Nation_2"].ToString() + "',");
                            //Str_SQL_Exec.Append("@S_NATION_3 =N'" + DT.Rows[0]["Nation_3"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_OFF_CALL_OPTION =N'" + DT.Rows[0]["OffCall_Option"].ToString() + "',");
                            Str_SQL_Exec.Append("@ApplyCode =N'" + DT.Rows[0]["ApplyCode"].ToString() + "',");
                            Str_SQL_Exec.Append("@ApplyYyymmdd =N'" + DT.Rows[0]["ApplyYyymmdd"].ToString() + "',");
                            Str_SQL_Exec.Append("@IssueSite =N'" + DT.Rows[0]["IssueSite"].ToString() + "',");
                            Str_SQL_Exec.Append("@PIC_1_OcrSN =N'" + DT.Rows[0]["PIC_1_OcrSN"].ToString() + "',");
                            Str_SQL_Exec.Append("@PIC_2_OcrSN =N'" + DT.Rows[0]["PIC_2_OcrSN"].ToString() + "',");
                            Str_SQL_Exec.Append("@IsIdCardApply =N'" + DT.Rows[0]["IsIdCardApply"].ToString() + "',");
                            Str_SQL_Exec.Append("@IdCardApply =N'" + DT.Rows[0]["IdCardApply"].ToString() + "',");
                            Str_SQL_Exec.Append("@S_LINE =N'" + DT.Rows[0]["S_LINE"].ToString() + "',");

                            Str_SQL_Exec.Append("@CASE_TYPE='N' ");

                            SqlCommand cmd_Exec = new SqlCommand(Str_SQL_Exec.ToString(), Conn_CRM);

                            SqlDataAdapter Ada_Exec = new SqlDataAdapter(cmd_Exec);
                            DataTable DT_Exec = new DataTable();
                            Ada_Exec.Fill(DT_Exec);
                        }

                    }
                    else
                    {
                        Str_Exception = "無暫存資料(SN：" + Str_Edit_SN + ")；故無法新增。";
                    }
                }
                catch (Exception ex)
                {
                    Str_Exception = ex.ToString();
                }
                #region === Write Log ===

                StringBuilder Str_Log = new StringBuilder();
                Str_Log.Append("功能 = 寫入CRM資料表 OM_OA_MAIN" + SetSplit);
                Str_Log.Append("程式 = API_Contract5Controller.cs/SaveData_CRM" + SetSplit);
                Str_Log.Append("UserID = " + Str_UserID + SetSplit);
                Str_Log.Append("DB ID = " + Str_Edit_SN + SetSplit);
                Str_Log.Append("CRM SQL = " + Str_SQL_Exec.ToString() + SetSplit);
                Str_Log.Append("步驟 = " + str_Step + SetSplit);
                if (Str_Exception != "")
                {
                    Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
                }
                if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
                {
                    LogClass.WriteLog("Contract1", Str_Log.ToString());
                }
                else
                {
                    LogClass.SCM_OpenAccounts_Log(Str_UserID, Str_Log.ToString(), ((Str_Exception != "") ? "1" : ""));
                }              
                if (Str_Exception != "")
                {
                    Str_Msg = "申請失敗!!";
                }
                
                #endregion
            }
            else
            {
                Str_Msg = "申請失敗!!";
            }
            return Str_Msg;
        }
        #endregion

        #region === 更新開戶資訊資料 ===
        protected string SaveData_SCM(string str_Step, string str_ToCRM, string Str_UserID, string Str_Edit_SN,string DocumentID)
        {
            SqlConnection Conn_SCM = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SCM"].ToString());
            string Str_Exception = string.Empty;                                //紀錄errlog
            string Str_Msg = "";               

            string Str_Para = "";
            StringBuilder Str_SQL = new StringBuilder();
            StringBuilder Str_SQL_Exec = new StringBuilder();

            //新增資料
            if (!string.IsNullOrWhiteSpace(Str_UserID) && !string.IsNullOrWhiteSpace(Str_Edit_SN))
            {
                try
                {
                    StringBuilder Str_SQL_Update = new StringBuilder();
                    Str_SQL_Update.Append("UPDATE SCM_OpenAccounts ");
                    Str_SQL_Update.Append("SET ");
                    Str_SQL_Update.Append("ToCRM = @ToCRM, ");
                    Str_SQL_Update.Append("ContAmt = @ContAmt,");
                    Str_SQL_Update.Append("PayKind = @PayKind,");
                    Str_SQL_Update.Append("DocID = @DocID, ");
                    Str_SQL_Update.Append("DocDate = GETDATE(), ");
                    Str_SQL_Update.Append("ServerIP = @ServerIP, ");
                    Str_SQL_Update.Append("ClientIP = @ClientIP ");
                    Str_SQL_Update.Append("WHERE SN = @SN ");
                    Str_SQL_Update.Append("AND IDNO = @IDNO ");
                    SqlCommand cmd_Update = new SqlCommand(Str_SQL_Update.ToString(), Conn_SCM);
                    cmd_Update.Parameters.AddWithValue("@ToCRM", str_ToCRM);
                    //* cmd_Update.Parameters.AddWithValue("@ContAmt", hf_ContAmt.Value);
                    //*cmd_Update.Parameters.AddWithValue("@PayKind", hf_PayKind.Value);
                    cmd_Update.Parameters.AddWithValue("@DocID", DocumentID);
                    cmd_Update.Parameters.AddWithValue("@ServerIP", ConfigurationManager.AppSettings["Server_IP"].ToString());
                    cmd_Update.Parameters.AddWithValue("@ClientIP", LogClass.GetUserIP());
                    cmd_Update.Parameters.AddWithValue("@SN", Str_Edit_SN);
                    cmd_Update.Parameters.AddWithValue("@IDNO", Str_UserID);
                    Str_Para = cmd_Update.CommandText;
                    foreach (SqlParameter p in cmd_Update.Parameters)
                    {
                        Str_Para = Str_Para.Replace(p.ParameterName + ",", "'" + p.Value.ToString() + "',");
                    }
                    SqlDataAdapter Ada_Update = new SqlDataAdapter(cmd_Update);
                    DataTable DT_Update = new DataTable();
                    Ada_Update.Fill(DT_Update);


                }
                catch (Exception ex)
                {
                    Str_Exception = ex.ToString();
                }
                #region === Write Log ===

                StringBuilder Str_Log = new StringBuilder();
                Str_Log.Append("功能 = 更新資料表 SCM_OpenAccounts" + SetSplit);
                Str_Log.Append("程式 = API_Contract5Controller.cs/SaveData_SCM" + SetSplit);
                Str_Log.Append("UserID = " + Str_UserID + SetSplit);
                Str_Log.Append("DB ID = " + Str_Edit_SN + SetSplit);
                Str_Log.Append("SCM SQL = " + Str_Para.ToString() + SetSplit);
                Str_Log.Append("步驟 = " + str_Step + SetSplit);
                if (Str_Exception != "")
                {
                    Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
                }
                if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
                {
                    LogClass.WriteLog("Contract1", Str_Log.ToString());
                }
                else
                {
                    LogClass.SCM_OpenAccounts_Log(Str_UserID, Str_Log.ToString(), ((Str_Exception != "") ? "1" : ""));
                }

                if (Str_Exception != "")
                {
                    Str_Msg = "更新失敗!!";
                }
                
                #endregion
            }
            else
            {
                Str_Msg = "申新失敗!!";
            }
            return Str_Msg;
        }
        #endregion

    }
}