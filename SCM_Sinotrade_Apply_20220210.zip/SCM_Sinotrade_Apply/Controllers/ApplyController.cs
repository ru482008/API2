﻿using Newtonsoft.Json;
using project_class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Services;

namespace SCM_Sinotrade_Apply.Controllers
{
    public class ApplyController : Controller
    {
        //----------------------------------------//

        #region === 會員申請 首頁 ===
        public ActionResult Index()
        {
            //若Cookie存在，移除之
            if (SetCookies.HasValue())
            {
                //移除Cookies
                SetCookies.DelCookies();
            }

            //行銷代碼 - 專案代碼
            string Str_Prod = SQLInjection.SetValue(Request.QueryString["strProd"]);

            //行銷代碼 - 網頁來源代碼
            string Str_Web = SQLInjection.SetValue(Request.QueryString["strWeb"]);
                            

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
           
            //ViewBag.GetScript = CA_Plugin.GetScript();
            //產生驗章所需空欄位
            ViewBag.CA_Para = CA_Plugin.GetPara("", "QR_S_SCM", "", "PKCS7", "Y");

            return View();
        }
        #endregion

        #region === 會員申請 永豐投顧委任契約簽署說明 ===
        public ActionResult Apply1()
        {           

            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookie())
            {
                return RedirectToAction("Index", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetData();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;           
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            #endregion

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();
        }
        #endregion

        #region === 會員申請 填寫基本資料 ===
        public ActionResult Apply2()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookie())
            {
                return RedirectToAction("Index", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetData();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            #endregion

            //取申請資料           
            DataTable DT_Edit = CRM.GetDT_SCMData(Str_IDNO, Str_SN);
            if (DT_Edit.Rows.Count > 0)
            {
                //不可修改
                ViewBag.UserName = DT_Edit.Rows[0]["Name"].ToString().Trim();
                ViewBag.UserID = DT_Edit.Rows[0]["IDNO"].ToString().Trim();
                ViewBag.Birth = string.Format("{0}{1}{2}", DT_Edit.Rows[0]["Birthday_Year"].ToString().Trim(), DT_Edit.Rows[0]["Birthday_Month"].ToString().Trim(), DT_Edit.Rows[0]["Birthday_Day"].ToString().Trim());
                ViewBag.Sex = DT_Edit.Rows[0]["Sex"].ToString().Trim();
                ViewBag.Nation = DT_Edit.Rows[0]["Nation"].ToString().Trim();
                ViewBag.Phone = DT_Edit.Rows[0]["Phone"].ToString().Trim();
                ViewBag.RAddr = DT_Edit.Rows[0]["Addr1"].ToString().Trim();
                //可修改
                ViewBag.MAddr = DT_Edit.Rows[0]["Addr2"].ToString().Trim();
                ViewBag.EMail = DT_Edit.Rows[0]["EMail"].ToString().Trim();
                ViewBag.Tel2 = DT_Edit.Rows[0]["Tel2"].ToString().Trim();
                ViewBag.Marry = DT_Edit.Rows[0]["Marry"].ToString().Trim();
                ViewBag.Edut = DT_Edit.Rows[0]["Edut"].ToString().Trim();
                ViewBag.Career = DT_Edit.Rows[0]["Occt"].ToString().Trim();
                ViewBag.Career_Other = DT_Edit.Rows[0]["Occt_1"].ToString().Trim();
                ViewBag.OffInst = DT_Edit.Rows[0]["OffInst"].ToString().Trim();
                ViewBag.OffCall = DT_Edit.Rows[0]["OffCall_Option"].ToString().Trim();
                ViewBag.OffCall_Other = DT_Edit.Rows[0]["OffCall"].ToString().Trim();

                ViewBag.Tel3 = DT_Edit.Rows[0]["OffTel"].ToString().Trim();
                ViewBag.LINE = DT_Edit.Rows[0]["S_LINE"].ToString().Trim();
            }

            //職業類別
            DataTable DT_Career = GetCareer();
            ViewBag.DT_Career = DT_Career;

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();
        }
        #endregion

        #region === 會員申請 填寫基本資料KYC ===
        public ActionResult Apply3()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookie())
            {
                return RedirectToAction("Index", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetData();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            #endregion

            //取申請資料           
            DataTable DT_KYC = CRM.GetDT_SCMKYCData(Str_IDNO, Str_SN);

            if (DT_KYC.Rows.Count > 0)
            {

                //1
                ViewBag.KYC_02 = DT_KYC.Rows[0]["KYC_02"].ToString().Trim();
                ViewBag.KYC_03 = DT_KYC.Rows[0]["KYC_03"].ToString().Trim();
                string KYC_04 = DT_KYC.Rows[0]["KYC_04"].ToString().Trim();

                switch (KYC_04)
                {
                    case "1":
                        ViewBag.KYC_04_1 = "1";
                        ViewBag.KYC_04_2 = "";
                        break;
                    case "2":
                        ViewBag.KYC_04_1 = "";
                        ViewBag.KYC_04_2 = "1";
                        break;
                    case "3":
                        ViewBag.KYC_04_1 = "1";
                        ViewBag.KYC_04_2 = "2";
                        break;
                }
                ViewBag.KYC_05 = DT_KYC.Rows[0]["KYC_05"].ToString().Trim();
                ViewBag.KYC_06_1 = DT_KYC.Rows[0]["KYC_06_1"].ToString().Trim();
                ViewBag.KYC_07 = DT_KYC.Rows[0]["KYC_07"].ToString().Trim();
                ViewBag.KYC_08_1 = DT_KYC.Rows[0]["KYC_08_1"].ToString().Trim();
                string KYC_09 = DT_KYC.Rows[0]["KYC_09"].ToString().Trim();
                IList<string> KYC_09List = new List<string>();
                if (!string.IsNullOrWhiteSpace(KYC_09))
                {
                    KYC_09List = KYC_09.Split(',');
                    foreach (string str in KYC_09List)
                    {
                        switch (str)
                        {
                            case "1":
                                ViewBag.KYC_09_1 = str;
                                break;
                            case "2":
                                ViewBag.KYC_09_2 = str;
                                break;
                            case "3":
                                ViewBag.KYC_09_3 = str;
                                break;
                        }
                    }
                }
                ViewBag.KYC_09_Others = DT_KYC.Rows[0]["KYC_09_Others"].ToString().Trim();                
                ViewBag.KYC_10 = DT_KYC.Rows[0]["KYC_10"].ToString().Trim();
                ViewBag.KYC_10_Others = DT_KYC.Rows[0]["KYC_10_Others"].ToString().Trim();
                ViewBag.KYC_11 = DT_KYC.Rows[0]["KYC_11"].ToString().Trim();
                ViewBag.KYC_11_Others = DT_KYC.Rows[0]["KYC_11_Others"].ToString().Trim();
                ViewBag.KYC_12 = DT_KYC.Rows[0]["KYC_12"].ToString().Trim();
                string KYC_13 = DT_KYC.Rows[0]["KYC_13"].ToString().Trim();
                IList<string> KYC_13List = new List<string>();
                if (!string.IsNullOrWhiteSpace(KYC_13))
                {
                    KYC_13List = KYC_13.Split(',');
                    foreach (string str in KYC_13List)
                    {
                        switch (str)
                        {
                            case "1":
                                ViewBag.KYC_13_1 = str;
                                break;
                            case "2":
                                ViewBag.KYC_13_2 = str;
                                break;
                            case "3":
                                ViewBag.KYC_13_3 = str;
                                break;
                            case "4":
                                ViewBag.KYC_13_4 = str;
                                break;
                            case "5":
                                ViewBag.KYC_13_5 = str;
                                break;
                            case "6":
                                ViewBag.KYC_13_6 = str;
                                break;
                            case "7":
                                ViewBag.KYC_13_7 = str;
                                break;
                            case "8":
                                ViewBag.KYC_13_8 = str;
                                break;
                        }
                    }
                }
                ViewBag.KYC_13_Others = DT_KYC.Rows[0]["KYC_13_Others"].ToString().Trim();
                //2
                ViewBag.KYC_14 = DT_KYC.Rows[0]["KYC_14"].ToString().Trim();
                ViewBag.KYC_15 = DT_KYC.Rows[0]["KYC_15"].ToString().Trim();
                ViewBag.KYC_16 = DT_KYC.Rows[0]["KYC_16"].ToString().Trim();
                ViewBag.KYC_17 = DT_KYC.Rows[0]["KYC_17"].ToString().Trim();
                ViewBag.KYC_18 = DT_KYC.Rows[0]["KYC_18"].ToString().Trim();
                ViewBag.KYC_19 = DT_KYC.Rows[0]["KYC_19"].ToString().Trim();
                ViewBag.KYC_19_Others = DT_KYC.Rows[0]["KYC_19_Others"].ToString().Trim();
                ViewBag.KYC_20 = DT_KYC.Rows[0]["KYC_20"].ToString().Trim();

                //3
                string KYC_21 = DT_KYC.Rows[0]["KYC_21"].ToString().Trim();
                IList<string> KYC_21List = new List<string>();
                if (!string.IsNullOrWhiteSpace(KYC_21))
                {
                    KYC_21List = KYC_21.Split(',');
                    foreach (string str in KYC_21List)
                    {
                        switch (str)
                        {
                            case "1":
                                ViewBag.KYC_21_1 = str;
                                break;
                            case "2":
                                ViewBag.KYC_21_2 = str;
                                break;
                            case "3":
                                ViewBag.KYC_21_3 = str;
                                break;
                            case "4":
                                ViewBag.KYC_21_4 = str;
                                break;
                            case "5":
                                ViewBag.KYC_21_5 = str;
                                break;
                            case "6":
                                ViewBag.KYC_21_6 = str;
                                break;
                            case "7":
                                ViewBag.KYC_21_7 = str;
                                break;
                            case "8":
                                ViewBag.KYC_21_8 = str;
                                break;
                            case "9":
                                ViewBag.KYC_21_9 = str;
                                break;
                            case "10":
                                ViewBag.KYC_21_10 = str;
                                break;
                            case "11":
                                ViewBag.KYC_21_11 = str;
                                break;
                            case "12":
                                ViewBag.KYC_21_12 = str;
                                break;
                        }
                    }
                }

                ViewBag.KYC_21_11_1 = DT_KYC.Rows[0]["KYC_21_11_1"].ToString().Trim();
                ViewBag.KYC_21_Others = DT_KYC.Rows[0]["KYC_21_Others"].ToString().Trim();
            }


            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;

            #region ::: Write Log :::
            //Log 字串
            //Log 分隔字串
            string SetSplit = ConfigurationManager.AppSettings["LogSplit"].ToString();
            StringBuilder Str_Log = new StringBuilder();
            Str_Log = new StringBuilder();
            Str_Log.Append("功能 = Apply3" + SetSplit);
            Str_Log.Append("程式 = ApplyController.cs/assignbranch" + SetSplit);
            Str_Log.Append("Exception = " + SetSplit);
            Str_Log.Append("Str_IDNO = "+ Str_IDNO + SetSplit);
            Str_Log.Append("Str_SN = " + Str_SN + SetSplit);
            LogClass.SCM_OpenAccounts_Log(Str_IDNO, Str_Log.ToString(), "");
            

            #endregion

            return View();
        }
        #endregion

        #region === 會員申請 契約簽署 ===
        public ActionResult Apply4()
        { 
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookie())
            {
                return RedirectToAction("Index", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetData();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_P1 = Obj_UserInfo.SIGN_P1;
            #endregion
            LogClass.WriteLog("Contract1", "Str_SIGN_P1:" + Str_SIGN_P1);
            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;

            //產生驗章所需空欄位
            ViewBag.CA_Para = CA_Plugin.GetPara("", "QR_S_SCM", "", "PKCS7", "Y");
            ViewBag.SIGN_P1 = Str_SIGN_P1;

            return View();
        }
        #endregion

        #region === 會員申請 會員申請成功 ===
        public ActionResult Apply5()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookie())
            {
                return RedirectToAction("Index", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetData();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            #endregion

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;


            DataTable DT_SCM = CRM.GetDT_SCMData(Str_IDNO, Str_SN);
            if (DT_SCM.Rows.Count > 0)
            {
                //投顧會員項目清單顯示基本資料
                ViewBag.Name = DT_SCM.Rows[0]["Name"].ToString().Trim();       //姓名
                ViewBag.Phone = DT_SCM.Rows[0]["Phone"].ToString().Trim();     //電話
                ViewBag.EMail = DT_SCM.Rows[0]["EMail"].ToString().Trim();     //E-mail

            }

            //若Cookie存在，移除之
            if (SetCookies.HasValue())
            {
                //移除Cookies
                SetCookies.DelCookies();
            }


            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();                      
        }
        #endregion

        #region === 職業類別 ===
        public DataTable GetCareer()
        {
            DataTable DT = new DataTable();
            DT.Columns.Add("Code", typeof(string));
            DT.Columns.Add("Name", typeof(string));

            try
            {
                SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_CRM"].ToString());
                StringBuilder Str_SQL = new StringBuilder();
                Str_SQL.Append("Select PARAM_VAL AS Code, PARAM_DESC AS NAME ");
                Str_SQL.Append("From SYS_PARAM_GRP_D ");
                Str_SQL.Append("WHERE PARAM_TYPE_ID = 'OM_OA_MAIN' AND PARAM_GRP_ID = 'OCCT_CODE' and DELETION = '0' ");
                Str_SQL.Append("ORDER BY Code ASC ");
                SqlCommand cmd = new SqlCommand(Str_SQL.ToString(), Conn);
                SqlDataAdapter Ada = new SqlDataAdapter(cmd);
                Ada.Fill(DT);
            }
            catch (Exception)
            {

            }

            return DT;
        }
        #endregion        

        #region === 訂閱服務 契約簽署1 ===
        public ActionResult SCM_Contract1()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookie())
            {
                return RedirectToAction("Index", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetData();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_P1 = Obj_UserInfo.SIGN_P1;
            #endregion
            ViewBag.SIGN_P1 = Str_SIGN_P1;
            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();            
        }
        #endregion

        #region === 訂閱服務 是否接續前次申請 ===
        public ActionResult ApplyCont()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookie())
            {
                return RedirectToAction("Index", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetData();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;

            #endregion

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();
        }
        #endregion



        #region === 變更密碼 驗證帳號 ===
        public ActionResult SetPW1()
        {
            //若Cookie存在，移除之
            if (SetCookies.HasValuePWD())
            {
                //移除Cookies
                SetCookies.DelCookiesPWD();
            }

            //行銷代碼 - 專案代碼
            string Str_Prod = SQLInjection.SetValue(Request.QueryString["strProd"]);

            //行銷代碼 - 網頁來源代碼
            string Str_Web = SQLInjection.SetValue(Request.QueryString["strWeb"]);

            //預設永豐投顧會員專區
            if (string.IsNullOrWhiteSpace(Str_Prod))
            {
                Str_Prod = "0018";
            }
            if (string.IsNullOrWhiteSpace(Str_Web))
            {
                Str_Web = "0023";
            }


            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;

            return View();
        }
        #endregion

        #region === 變更密碼 OTP驗證 ===
        public ActionResult SetPW2()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookiePWD())
            {
                return RedirectToAction("SetPW1", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataPWD();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            #endregion

            //驗證碼
            string Str_ReCode = SQLInjection.SetValue(Request.QueryString["Code"]);

            string Str_Phone = "";

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                //(測試用)若有值，僅傳送給該手機號碼
                if (ConfigurationManager.AppSettings["OTP_Receiver"] != "")
                {
                    Str_Phone = ConfigurationManager.AppSettings["OTP_Receiver"];
                }
                ViewBag.MOBLE = MaskPhone(Str_Phone);
                ViewBag.Prod = Str_Prod;
                ViewBag.Web = Str_Web;
                ViewBag.Code = Str_ReCode;
                return View();
            }
            else {
                //取得客戶基本資料
                DataTable DT = CRM.GetCusData(Str_IDNO);
                if (DT.Rows.Count > 0)
                {
                    //判斷是否為同一個身份證字號
                    if (Str_IDNO.Equals(DT.Rows[0]["S_IDNO"].ToString().Trim()))
                    {
                        //手機號碼
                        Str_Phone = MaskPhone(DT.Rows[0]["S_MOBLE"].ToString().Trim());
                    }

                    //(測試用)若有值，僅傳送給該手機號碼
                    if (ConfigurationManager.AppSettings["OTP_Receiver"] != "")
                    {
                        Str_Phone = ConfigurationManager.AppSettings["OTP_Receiver"];
                    }
                    ViewBag.MOBLE = MaskPhone(Str_Phone);
                    ViewBag.Prod = Str_Prod;
                    ViewBag.Web = Str_Web;
                    ViewBag.Code = Str_ReCode;
                    return View();
                }
                else
                {
                    return RedirectToAction("error", "Apply");
                }
            }
                

        }

        #region === 手機號碼遮罩 ===
        public string MaskPhone(string Str_Phone)
        {
            string Str_Return = "";

            if (Str_Phone.Length >= 10)
            {
                Str_Return = Str_Phone.Substring(0, 4) + " XXX " + Str_Phone.Substring(Str_Phone.Length - 3, 3);
            }

            return Str_Return;
        }
        #endregion
        #endregion

        #region === 變更密碼 密碼設定 ===
        public ActionResult SetPW3()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookiePWD())
            {
                return RedirectToAction("SetPW1", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataPWD();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            #endregion

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                ViewBag.Prod = Str_Prod;
                ViewBag.Web = Str_Web;
                return View();
            }
            else {
                //取得客戶基本資料
                DataTable DT = CRM.GetCusData(Str_IDNO);
                if (DT.Rows.Count > 0)
                {
                    ViewBag.Prod = Str_Prod;
                    ViewBag.Web = Str_Web;
                    return View();
                }
                else
                {
                    return RedirectToAction("error", "Apply");
                }
            }
                

           
        }
        #endregion

        #region === 變更密碼 END ===
        public ActionResult SetPW4()
        {
            //若Cookie存在，移除之
            if (SetCookies.HasValuePWD())
            {
                //移除Cookies
                SetCookies.DelCookiesPWD();
            }

            ViewBag.URL = ConfigurationManager.AppSettings["URL"].ToString();
            return View();
        }
        #endregion


        #region === 訂閱服務 首頁 ===
        public ActionResult Contract1()
        {
            //若Cookie存在，移除之
            if (SetCookies.HasValueCON())
            {
                //移除Cookies
                SetCookies.DelCookiesCON();
            }

            //行銷代碼 - 專案代碼
            string Str_Prod = SQLInjection.SetValue(Request.QueryString["strProd"]);
            //行銷代碼 - 網頁來源代碼
            string Str_Web = SQLInjection.SetValue(Request.QueryString["strWeb"]);
            //來源別
            string Str_DirType = SQLInjection.SetValue(Request.QueryString["dirtype"]);
            

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            ViewBag.DirType = Str_DirType;

            //ViewBag.GetScript = CA_Plugin.GetScript();
            //產生驗章所需空欄位
            ViewBag.CA_Para = CA_Plugin.GetPara("", "QR_S_SCM", "", "PKCS7", "Y");

            return View();
        }
        #endregion

        #region === 訂閱服務 商品購買聲明 ===
        public ActionResult Contract2()
        {           
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion          

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_DirType = Obj_UserInfo.DirType;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_CON1 = Obj_UserInfo.SIGN_CON1;
            string Str_SIGN_P2 = Obj_UserInfo.SIGN_P2;
            #endregion

            LogClass.WriteLog("Contract1", "Str_SN:"+ Str_SN);

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();            
        }
        #endregion

        #region === 訂閱服務 請選擇欲購買之顧問商品 ===
        public ActionResult Contract3()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_DirType = Obj_UserInfo.DirType;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_CON1 = Obj_UserInfo.SIGN_CON1;
            string Str_SIGN_P2 = Obj_UserInfo.SIGN_P2;
            #endregion

            #region ::: 檢查簽署 :::
            if (!"1".Equals(Str_SIGN_CON1))
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion

            #region ::: 商品 :::
            IList<BUY_CONT> bcList = new List<BUY_CONT>();
            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                BUY_CONT bc = new BUY_CONT();
                bc.CONT_NO = "P00001";
                bc.CONT_NAME = "白金會員";
                bc.CONT_Amt = "1,791";
                bc.CONT_AmtShow = "1,791";
                bc.CONT_Item = "3個月";
                bc.CONT_Note = "含研報會員權益及專屬Line群單向體驗";
                bc.CONT_MustBuyFlag = "N";
                bcList.Add(bc);
                bc = new BUY_CONT();
                bc.CONT_NO = "P00001";
                bc.CONT_NAME = "黑金會員";
                bc.CONT_Amt = "1,791";
                bc.CONT_AmtShow = "1,791";
                bc.CONT_Item = "3個月";
                bc.CONT_Note = "含研報會員權益及專屬Line群單向體驗";
                bc.CONT_MustBuyFlag = "N";
                bcList.Add(bc);
            }
            else {                               
                DataTable DTCusCont = CRM.GetCusCont(Str_IDNO, Str_DirType, "");
                if (DTCusCont.Rows.Count > 0)
                {
                    for (int i = 0; i < DTCusCont.Rows.Count; i++)
                    {
                        BUY_CONT bc = new BUY_CONT();
                        bc.CONT_NO = DTCusCont.Rows[i]["CONT_NO"].ToString();
                        bc.CONT_NAME = DTCusCont.Rows[i]["CONT_NAME"].ToString();
                        bc.CONT_Amt = DTCusCont.Rows[i]["CONT_AMT"].ToString();
                        bc.CONT_AmtShow = DTCusCont.Rows[i]["CONT_AMT_SHOW"].ToString();
                        bc.CONT_Item = DTCusCont.Rows[i]["CONT_ITEM"].ToString();
                        bc.CONT_Note = DTCusCont.Rows[i]["CONT_NOTE"].ToString();
                        bc.CONT_MustBuyFlag = DTCusCont.Rows[i]["MUSTBUY_FLAG"].ToString();
                        if (!"A000001".Equals(bc.CONT_NO))
                        {
                            bcList.Add(bc);
                        }
                    }
                }
                else
                {
                    //無顧問商品
                }
            }
               
            #endregion
            ViewBag.CONTList = bcList;
            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();
        }

        #region === 商品 ===
        public class BUY_CONT
        {
            public string CONT_NO { get; set; }  //商品Key
            public string CONT_NAME { get; set; }  //商品名稱
            public string CONT_Amt { get; set; }     //費用
            public string CONT_AmtShow { get; set; }     //費用
            public string CONT_Item { get; set; }     //期間
            public string CONT_Note { get; set; }     //內容
            public string CONT_MustBuyFlag { get; set; }     //必買
        }
        #endregion
        #endregion

        #region === 訂閱服務 填寫基本資料 ===
        public ActionResult Contract4()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_DirType = Obj_UserInfo.DirType;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_CON1 = Obj_UserInfo.SIGN_CON1;
            string Str_SIGN_P2 = Obj_UserInfo.SIGN_P2;
            #endregion

            #region ::: 檢查權限 :::
            if (!"1".Equals(Str_SIGN_CON1))
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {//不可修改
                ViewBag.UserName = "AAA";
                ViewBag.UserID = "ABCAAAAAAAAAAAAA";
                ViewBag.Phone = "090XXXXXXXX";

                //可修改
                ViewBag.MAddr = "";
                ViewBag.EMail = "";
            }
            else {
                //取申請資料           
                DataTable DT_Edit = CRM.GetDT_SCMData(Str_IDNO, Str_SN);
                if (DT_Edit.Rows.Count > 0)
                {
                    //不可修改
                    ViewBag.UserName = DT_Edit.Rows[0]["Name"].ToString().Trim();
                    ViewBag.UserID = DT_Edit.Rows[0]["IDNO"].ToString().Trim();                    
                    ViewBag.Phone = DT_Edit.Rows[0]["Phone"].ToString().Trim();
                    
                    //可修改
                    ViewBag.MAddr = DT_Edit.Rows[0]["MAddr2"].ToString().Trim();
                    ViewBag.EMail = DT_Edit.Rows[0]["EMail"].ToString().Trim();                   
                }
            }
               

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();
        }
        #endregion

        #region === 訂閱服務 契約簽署 ===
        public ActionResult Contract5()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_DirType = Obj_UserInfo.DirType;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_CON1 = Obj_UserInfo.SIGN_CON1;
            string Str_SIGN_P2 = Obj_UserInfo.SIGN_P2;

            #endregion

            #region ::: 檢查權限 :::
            if (!"1".Equals(Str_SIGN_CON1))
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion
            
            ViewBag.SIGN_P2 = Str_SIGN_P2;
            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();
                     
        }
        #endregion

        #region === 訂閱服務 訂閱申請確認 ===
        public ActionResult Contract6()
        {

            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_DirType = Obj_UserInfo.DirType;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_CON1 = Obj_UserInfo.SIGN_CON1;
            string Str_SIGN_P2 = Obj_UserInfo.SIGN_P2;

            #endregion

            #region ::: 檢查權限 :::
            if (!"1".Equals(Str_SIGN_CON1))
            {
                return RedirectToAction("Contract1", "Apply");
            }

            if (!"1".Equals(Str_SIGN_P2))
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion
            IList<BUY_CONT> bcList = new List<BUY_CONT>();
            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {                
                ViewBag.Name = "王小明";       //姓名
                ViewBag.Phone = "09xxxxxxxx";     //電話
                ViewBag.EMail = "tttt@gmail.com";     //E-mail

                BUY_CONT bc = new BUY_CONT();
                bc.CONT_NO = "P00001";
                bc.CONT_NAME = "白金會員";
                bc.CONT_Amt = "1,791";
                bc.CONT_AmtShow = "1,791";
                bc.CONT_Item = "3個月";
                bc.CONT_Note = "含研報會員權益及專屬Line群單向體驗";
                bc.CONT_MustBuyFlag = "N";
                bcList.Add(bc);
                bc = new BUY_CONT();
                bc.CONT_NO = "P00001";
                bc.CONT_NAME = "黑金會員";
                bc.CONT_Amt = "1,791";
                bc.CONT_AmtShow = "1,791";
                bc.CONT_Item = "3個月";
                bc.CONT_Note = "含研報會員權益及專屬Line群單向體驗";
                bc.CONT_MustBuyFlag = "N";
                bcList.Add(bc);
            }
            else {
                DataTable DT_SCM = CRM.GetDT_SCMData(Str_IDNO, Str_SN);
                if (DT_SCM.Rows.Count > 0)
                {
                    //投顧會員項目清單顯示基本資料
                    ViewBag.Name = DT_SCM.Rows[0]["Name"].ToString().Trim();       //姓名
                    ViewBag.Phone = DT_SCM.Rows[0]["Phone"].ToString().Trim();     //電話
                    ViewBag.EMail = DT_SCM.Rows[0]["EMail"].ToString().Trim();     //E-mail

                    string Str_CusCont = DT_SCM.Rows[0]["CusCont"].ToString();
                    //顯示購買的策略                    
                    DataTable DT_Cont = CRM.GetDT_ContData(Str_IDNO, Str_DirType, Str_CusCont);
                    if (DT_Cont.Rows.Count > 0)
                    {
                        for (int i = 0; i < DT_Cont.Rows.Count; i++)
                        {
                            BUY_CONT bc = new BUY_CONT();
                            bc.CONT_NO = DT_Cont.Rows[i]["CONT_NO"].ToString();
                            bc.CONT_NAME = DT_Cont.Rows[i]["CONT_NAME"].ToString();
                            bc.CONT_Amt = DT_Cont.Rows[i]["CONT_AMT"].ToString();
                            bc.CONT_AmtShow = DT_Cont.Rows[i]["CONT_AMT_SHOW"].ToString();
                            bc.CONT_Item = DT_Cont.Rows[i]["CONT_ITEM"].ToString();
                            bc.CONT_Note = DT_Cont.Rows[i]["CONT_NOTE"].ToString();
                            bc.CONT_MustBuyFlag = DT_Cont.Rows[i]["MUSTBUY_FLAG"].ToString();
                            if (!"A000001".Equals(bc.CONT_NO))
                            {
                                bcList.Add(bc);
                            }
                        }
                    }

                }

            }

            ViewBag.CONTList = bcList;
            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();
        }
        #endregion

        #region === 訂閱服務 訂閱申請成功 ===
        public ActionResult Contract7()
        {

            //若Cookie存在，移除之
            if (SetCookies.HasValueCON())
            {
                //移除Cookies
                SetCookies.DelCookiesCON();
            }


            string SetSplit = ConfigurationManager.AppSettings["LogSplit"];   //Log 分隔字串

            StringBuilder Str_Log = new StringBuilder();

            string Status = SQLInjection.SetValue(Request.Form["Status"]);          //回傳狀態
            string TradeInfo = SQLInjection.SetValue(Request.Form["TradeInfo"]);    //加密內容
            string MerchantID = SQLInjection.SetValue(Request.Form["MerchantID"]);  //商店代號
            string strProd = SQLInjection.SetValue(Request.QueryString["strProd"]);
            string strWeb = SQLInjection.SetValue(Request.QueryString["strWeb"]);         

            string Str_TradeInfo = "";
            if (!string.IsNullOrEmpty(TradeInfo))
            {
                Str_TradeInfo = Encryption.DecryptAES256(TradeInfo);
            }
            

            #region === Step Log ===

            Str_Log.Append("功能 = 藍新平台跳轉結果頁 開始" + SetSplit);
            Str_Log.Append("程式 = ApplyController.cs/Contract7" + SetSplit);
            Str_Log.Append("Status = " + Status + SetSplit);
            Str_Log.Append("MerchantID = " + MerchantID + SetSplit);
            //Str_Log.Append("PayAmtNo = " + Str_PayAmtNo + SetSplit);
            Str_Log.Append("TradeInfo = " + TradeInfo + SetSplit);
            Str_Log.Append("TradeInfo解密 = " + Str_TradeInfo + SetSplit);
            #endregion

            if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
            {
                LogClass.WriteLog("Contract1", Str_Log.ToString());
            }
            else
            {                
                LogClass.SCM_OpenAccounts_Log(MerchantID, Str_Log.ToString(),"");
            }
           

            StringBuilder Str_SQL_Exec = new StringBuilder();
            try
            {
                if (!string.IsNullOrEmpty(Status))
                {
                    if (Status == "SUCCESS")
                    {
                      

                    }
                    else
                    {
                       
                    }
                }
                if (!string.IsNullOrEmpty(Str_TradeInfo))
                {

                }

            }
            catch (Exception ex)
            {
                string Str_Exception = ex.ToString();

                if (Str_Exception != "")
                {
                    Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
                }

                if ("true".Equals(ConfigurationManager.AppSettings["isTest"].ToString()))
                {
                    LogClass.WriteLog("Contract1", Str_Log.ToString());
                }
                else
                {
                    LogClass.SCM_OpenAccounts_Log(MerchantID, Str_Log.ToString(), ((Str_Exception != "") ? "1" : ""));
                }                

            }
         
            ViewBag.Status = Status;
            return View();
        }

        #endregion

        #region === 訂閱服務 契約簽署2 ===
        public ActionResult SCM_Contract2()
        {
            #region ::: 檢查權限 :::
            if (!SetCookies.CheckCookieCON())
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion

            #region ::: Cookies 資訊 :::

            var Obj_UserInfo = SetCookies.GetDataCON();
            string Str_SN = Obj_UserInfo.SN;
            string Str_Prod = Obj_UserInfo.Prod;
            string Str_Web = Obj_UserInfo.Web;
            string Str_IDNO = Obj_UserInfo.IDNO;
            string Str_EnID = Obj_UserInfo.EnID;
            string Str_Date = Obj_UserInfo.Date;
            string Str_IP = Obj_UserInfo.IP;
            string Str_SIGN_CON1 = Obj_UserInfo.SIGN_CON1;
            string Str_SIGN_P2 = Obj_UserInfo.SIGN_P2;

            #endregion

            #region ::: 檢查權限 :::
            if (!"1".Equals(Str_SIGN_CON1))
            {
                return RedirectToAction("Contract1", "Apply");
            }
            #endregion
           
            ViewBag.SIGN_P2 = Str_SIGN_P2;
            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            return View();           
        }
        #endregion


        public ActionResult test()
        {
            //產生驗章所需空欄位
            ViewBag.CA_Para = CA_Plugin.GetPara("", "QR_S_SCM", "", "PKCS7", "Y");
            string Str_IDNO = "RCCDACIBFG";
            string Str_QRDocumentID = "208569821277618744910221326007889105";
            ViewBag.QR_Doc = "<a href='" + ConfigurationManager.AppSettings["WebSite_URL"] + "/QR_Doc_Test?IDNO=" + Str_IDNO + "&D=" + Str_QRDocumentID + "' target='_blank'>下載PDF</a>";

            ////POST傳遞參數
            //var url = "";

            //Response.Clear();
            //var sb = new System.Text.StringBuilder();
            //sb.Append("<html>");
            //sb.AppendFormat("<body>");
            //sb.AppendFormat("<form >");
            //sb.Append("AAAA");

            //sb.Append("</form>");
            //sb.Append("</body>");
            //sb.Append("</html>");
            //Response.Write(sb.ToString());
            //Response.End();
            return View();
        }

        #region === 藍新金流平台 ===
        public void NeWebPay()
        {
            string SetSplit = ConfigurationManager.AppSettings["LogSplit"];   //Log 分隔字串

            StringBuilder Str_Log = new StringBuilder();

            string Status = SQLInjection.SetValue(Request.QueryString["Status"]);
            string TradeInfo = SQLInjection.SetValue(Request.QueryString["TradeInfo"]);
            string MerchantID = SQLInjection.SetValue(Request.QueryString["MerchantID"]);
            
            LogClass.WriteLog("Contract1", "Status:" + Status);
            LogClass.WriteLog("Contract1", "TradeInfo:" + TradeInfo);
            LogClass.WriteLog("Contract1", "MerchantID:" + MerchantID);

            string Str_TradeInfo = "";
            if (!string.IsNullOrEmpty(TradeInfo))
            {
                Str_TradeInfo = Encryption.DecryptAES256(TradeInfo);
            }

            #region === Step Log ===

            Str_Log.Append("功能 = 藍新平台回覆 步驟一：回傳值" + SetSplit);
            Str_Log.Append("程式 = API_NeWebPayController.cs" + SetSplit);
            Str_Log.Append("Status = " + Status + SetSplit);
            Str_Log.Append("MerchantID = " + MerchantID + SetSplit);
            //Str_Log.Append("PayAmtNo = " + Str_PayAmtNo + SetSplit);
            Str_Log.Append("TradeInfo = " + TradeInfo + SetSplit);
            Str_Log.Append("TradeInfo解密 = " + Str_TradeInfo + SetSplit);
            #endregion
            LogClass.SCM_OpenAccounts_Log(MerchantID, Str_Log.ToString(), "");


            StringBuilder Str_SQL_Exec = new StringBuilder();
            try
            {
                if (!string.IsNullOrEmpty(Str_TradeInfo))
                {
                    //StringBuilder jsonData = new StringBuilder();

                    //Str_TradeInfo = Str_TradeInfo.Replace("\"", "'");
                    //JsonData json_result = JsonMapper.ToObject(Str_TradeInfo);

                    //string Str_MerchantID = json_result["Result"]["MerchantID"].ToString();
                    //string Str_TradeNo = json_result["Result"]["TradeNo"].ToString();
                    //string Str_PayAmtNo = json_result["Result"]["MerchantOrderNo"].ToString();
                    //string Str_PayKind = json_result["Result"]["PaymentMethod"].ToString();
                    //string Str_IP = json_result["Result"]["IP"].ToString();
                    ////C：CREDIT 信用卡 T：VACC 轉帳 M：現金
                    ////G: GOOGLEPAY S: SAMSUNGPAY
                    //switch (Str_PayKind)
                    //{
                    //    case "CREDIT":
                    //        Str_PayKind = "C";
                    //        break;
                    //    case "VACC":
                    //        Str_PayKind = "T";
                    //        break;
                    //    case "GOOGLEPAY":
                    //        Str_PayKind = "G";
                    //        break;
                    //    case "SAMSUNGPAY":
                    //        Str_PayKind = "S";
                    //        break;
                    //    default:
                    //        Str_PayKind = "";
                    //        break;
                    //}


                    //Str_SQL_Exec.Append("EXEC SP_OM_OA_MAIN_UPD ");
                    //Str_SQL_Exec.Append("@SEQ_NO=0,@FUNC_TYPE='B', ");
                    ////銷帳編號               
                    //Str_SQL_Exec.Append("@PAY_AMT_NO = '" + Str_PayAmtNo + "',");
                    //Str_SQL_Exec.Append("@PAY_TYPE = '" + ((Status == "SUCCESS") ? "Y" : "N") + "',");
                    //Str_SQL_Exec.Append("@PAY_KIND = '" + Str_PayKind + "',");
                    //Str_SQL_Exec.Append("@S_IP = '" + Str_IP + "',");
                    //Str_SQL_Exec.Append("@TRADE_NO='" + Str_TradeNo + "' ");

                    //SqlConnection Conn_CRM = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_CRM"].ToString());
                    //SqlCommand cmd_Exec = new SqlCommand(Str_SQL_Exec.ToString(), Conn_CRM);

                    //SqlDataAdapter Ada_Exec = new SqlDataAdapter(cmd_Exec);
                    //DataTable DT_Exec = new DataTable();
                    //Ada_Exec.Fill(DT_Exec);

                    //#region === Step Log ===
                    //Str_Log.Clear();
                    //Str_Log.Append("功能 = 藍新平台回覆 開始 步驟二：更新CRM" + SetSplit);
                    //Str_Log.Append("程式 = JSON/NeWebPay.aspx.cs" + SetSplit);
                    //Str_Log.Append("CRM SQL = " + Str_SQL_Exec.ToString() + SetSplit);
                    //#endregion                    
                    //LogClass.SCM_OpenAccounts_Log(MerchantID, Str_Log.ToString(), "");
                }

            }
            catch (Exception ex)
            {

                string Str_Exception = ex.ToString();

                if (Str_Exception != "")
                {
                    Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
                }
                LogClass.SCM_OpenAccounts_Log(MerchantID, Str_Log.ToString(), ((Str_Exception != "") ? "1" : ""));

            }            
        }

        #region === 藍新金流平台結果 ===
        [WebMethod]
        public static void CallResult(string Status, string MerchantID, string TradeInfo, string TradeSha)
        {

            //回傳中文訊息
            string Str_MSG = "";

            //try{}catch(){}錯誤訊息
            string Str_Exception = "";

            string Str_StartTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            string SetSplit = ConfigurationManager.AppSettings["LogSplit"];   //Log 分隔字串

            StringBuilder Str_Log = new StringBuilder();

        }
        #endregion

        #region === 欄位定義 ===
        public class JSON_Object
        {
            public string ReCode { get; set; }        //回傳訊息碼：
            public string CodeMsg { get; set; }     //回傳中文訊息

        }
        public class JSON_NeObj
        {
            public string MerchantID { get; set; }
            public string RespondType { get; set; }
            public string TimeStamp { get; set; }
            public string Version { get; set; }
            public string LangType { get; set; }
            public string MerchantOrderNo { get; set; }
            public decimal Amt { get; set; }
            public string CodeMsg { get; set; }


        }
        #endregion
        #endregion

        #region === 公版錯誤頁 ===
        public ActionResult error()
        {
            string Str_MSG = "";        //錯誤訊息
            string Str_DisErrCode = ""; //顯示錯誤代碼
            string Str_BtnName = "確定";//按鈕名稱
            string Str_URL = "";        //按鈕前往下一頁 URL

            //行銷代碼 - 專案代碼
            string Str_Prod = SQLInjection.SetValue(Request.QueryString["strProd"]);

            //行銷代碼 - 網頁來源代碼
            string Str_Web = SQLInjection.SetValue(Request.QueryString["strWeb"]);

            //來源頁面
            string Str_Source = SQLInjection.SetValue(Request.QueryString["s"]);

            //錯誤代碼
            string ErrCode = SQLInjection.SetValue(Request.QueryString["e"]);

            //行銷活動指定 - 分公司代碼
            string Str_Assign_Broker = SQLInjection.SetValue(Request.QueryString["ab"]);

            //行銷活動指定 - 營業員
            string Str_Assign_ADNO = SQLInjection.SetValue(Request.QueryString["as"]);
            string Str_EnID = SQLInjection.SetValue(Request.QueryString["eid"]);
            string Str_MonthDay = SQLInjection.SetValue(Request.QueryString["md"]);

            switch (ErrCode)
            {
                //市場違約，不可進行線上開戶作業
                case "BContract":
                    Str_MSG = "很抱歉，您不符合線上開戶資格，謝謝您的申請";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //已存在行銷活動指定 - 分公司 ST 證券帳戶
                case "Assign_Broker":
                    string Str_BrokerName = (Str_Assign_Broker != "") ? SysCode.GetBrokerName(Str_Assign_Broker) : "";
                    Str_BrokerName = (Str_BrokerName != "") ? Str_Assign_Broker + Str_BrokerName : "";
                    Str_MSG = "很抱歉，" + Str_BrokerName + "您已存在證券帳戶，謝謝您的申請";
                    Str_DisErrCode = "";
                    if (Str_Assign_Broker != "")
                    {
                        Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web, @b = Str_Assign_Broker });
                    }
                    else
                    {
                        Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    }

                    break;

                //已存在行銷活動指定 - 營業員 ST 證券帳戶
                case "Assign_ADNO":
                    string Str_ADNO_BrokerName = "";
                    if (Str_Assign_ADNO != "")
                    {
                        string Str_IDNO = "";
                        if (Str_EnID != "" && Numeric.IsNumeric(Str_MonthDay))
                        {
                            Str_IDNO = (Encryption.isEnID()) ? Encryption.myDecode(Str_EnID, Convert.ToInt32(Str_MonthDay)) : Str_EnID;
                        }

                        string[] arySalse = SysCode.GetSalse(Str_Web, Str_IDNO, LogClass.GetUserIP(), Str_Assign_ADNO);
                        if (arySalse[0] == "Y")
                        {
                            if (arySalse[2] == Str_Assign_ADNO)
                            {
                                Str_ADNO_BrokerName = SysCode.GetBrokerName(arySalse[4]);
                                Str_ADNO_BrokerName = (Str_ADNO_BrokerName != "") ? arySalse[4] + Str_ADNO_BrokerName : "";
                            }
                        }
                    }
                    Str_MSG = "很抱歉，" + Str_ADNO_BrokerName + "您已存在證券帳戶，謝謝您的申請";
                    Str_DisErrCode = "";
                    if (Str_Assign_ADNO != "")
                    {
                        Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web, @s = Str_Assign_ADNO });
                    }
                    else
                    {
                        Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    }
                    break;

                //行銷活動指定 - 營業員工號 不存在
                case "Assign_ADNO_E":
                    Str_MSG = "很抱歉，查無此營業員";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //模擬測試 QR PDF 下載
                case "PDF_Test":
                    Str_MSG = "下載 PDF 失敗";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //下載證券PDF 
                case "PDF_ST":
                    Str_MSG = "下載受託買賣國內有價證券開戶契約總約定書-簡易版失敗";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //下載複委託PDF 
                case "PDF_SUB":
                    Str_MSG = "下載受託買賣外國有價證券開戶契約總約定書-簡易版失敗";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //下載PDF產品類別參數錯誤
                case "PDF_Kind":
                    Str_MSG = "參數傳遞錯誤";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //OTP 驗證時過期
                case "Expired":
                    Str_MSG = "您的OTP驗證時效已過，請重新申請，謝謝";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //行動電話號碼重複
                case "MultiPhone":
                    Str_MSG = "行動電話號碼重複，故不接受線上開戶，請重新確認";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //行動電話號碼重複
                case "MultiPhone_Error":
                    Str_MSG = "系統有誤，請聯絡客服專員" + ConfigurationManager.AppSettings["CallCenterTEL"];
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //Is24HR

                //查無申請記錄
                case "progressnull":
                    Str_MSG = "查無線上開戶申請資訊";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("progress", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;


                case "0401":
                    Str_MSG = "您輸入的資料驗證錯誤，請重新輸入，或洽詢銀行客服專線(02)2505-9999。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "0304":
                    Str_MSG = "本日身分驗證錯誤次數已達3次。為確保您的交易安全，本日已無法再進行身分驗證。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "0305":
                    Str_MSG = "本月身分驗證錯誤次數已達5次。為確保您的交易安全，本月已無法再進行身分驗證。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "0104":
                    Str_MSG = "您於本行未留存簡訊手機號碼，無法進行OTP認證。請洽詢銀行客服專線(02)2505-9999。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "0302":
                    Str_MSG = "本日簡訊驗證碼發送次數已達5次。為確保您的交易安全，今日已無法再進行身分驗證。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "0301":
                    Str_MSG = "本日簡訊驗證碼錯誤次數已達3次。為確保您的交易安全，本日已無法再進行身分驗證。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "0303":
                    Str_MSG = "本月簡訊驗證碼錯誤次數已達5次。為確保您的交易安全，本月已無法再進行身分驗證。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "1003":
                    Str_MSG = "您沒有可綁定「國內證券」與「海外證券」扣款之銀行帳戶，請洽詢銀行客服專線(02)2505-9999。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "1001":
                    Str_MSG = "您沒有可綁定「國內證券」扣款之銀行帳戶，請洽詢銀行客服專線(02)2505-9999。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                case "1002":
                    Str_MSG = "您沒有可綁定「海外證券」扣款之銀行帳戶，請洽詢銀行客服專線(02)2505-9999。";
                    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
                //case "9991":
                //    Str_MSG = "您沒有可綁定「海外證券」扣款之銀行帳戶，請洽詢銀行客服專線(02)2505-9999。";
                //    Str_DisErrCode = "錯誤代碼：" + ErrCode;
                //    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                //    break;

                //已存在9A95證券帳號
                case "HasSTAct":
                    Str_MSG = "您已經持有永豐金證券帳戶，故不接受證券線上開戶";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                //無法指定分公司
                case "AssignBKNO":
                    Str_MSG = "很抱歉，無法指定此分公司進行線上開戶";
                    Str_DisErrCode = "";
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;

                default:
                    Str_MSG = ConfigurationManager.AppSettings["WebSite_ERR_MSG"];
                    Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
                    break;
            }

            //防呆，未知錯誤，按下確定都導向申請首頁
            if (Str_URL == "")
            {
                Str_URL = Url.Action("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
            }

            ViewBag.Prod = Str_Prod;
            ViewBag.Web = Str_Web;
            ViewBag.MSG = Str_MSG;
            ViewBag.DisErrCode = Str_DisErrCode;
            ViewBag.BtnName = Str_BtnName;
            ViewBag.URL = Str_URL;

            return View();
        }
        #endregion

        //----------------------------------------//

        #region === 產生(ST)證券開戶契約書 Start ===
        public ActionResult processst()
        {
            //#region ::: 檢查權限 :::
            //if (!SetCookies.CheckCookie())
            //{
            //    return RedirectToAction("Index", "Apply");
            //}
            //#endregion

            //#region ::: Cookies 資訊 :::

            //var Obj_UserInfo = SetCookies.GetData();
            //string Str_SN = Obj_UserInfo.SN;
            //string Str_Prod = Obj_UserInfo.Prod;
            //string Str_Web = Obj_UserInfo.Web;
            //string Str_IDNO = Obj_UserInfo.IDNO;
            //string Str_EnID = Obj_UserInfo.EnID;
            //string Str_EditType = Obj_UserInfo.EditType;
            //string Str_PCode = Obj_UserInfo.PCode;
            //string Str_SNO = Obj_UserInfo.SNO;
            //string Str_Date = Obj_UserInfo.Date;
            //string Str_IP = Obj_UserInfo.IP;

            //#endregion

            //#region ::: 參數 :::

            //string Str_T = ((!String.IsNullOrEmpty(Request.QueryString["t"] as string)) ? SQLInjection.SetValue(Request.QueryString["t"].ToString().Trim()) : "");
            //string Str_C = ((!String.IsNullOrEmpty(Request.QueryString["c"] as string)) ? SQLInjection.SetValue(Request.QueryString["c"].ToString().Trim()) : "");
            //string Str_ReC = "";

            ////Log 分隔字串
            //string SetSplit = ConfigurationManager.AppSettings["LogSplit"].ToString();

            ////Log 字串
            //StringBuilder Str_Log = new StringBuilder();

            ////狀態： (Y)成功、(N)失敗
            //string Str_Status = "N";

            ////錯誤訊息
            //string Str_MSG = "";

            ////錯誤代碼
            //string Str_Code = "";

            ////API URL
            //string Str_URL = "";

            ////try{}catch(){}錯誤訊息
            //string Str_Exception = "";

            //#endregion

            //try
            //{
            //    SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
            //    StringBuilder Str_SQL = new StringBuilder();
            //    Str_SQL.Append("SELECT * ");
            //    Str_SQL.Append("FROM SpdOpenAct ");
            //    Str_SQL.Append("WHERE SN = @SN ");
            //    Str_SQL.Append("AND IDNO = @IDNO ");
            //    SqlCommand cmd = new SqlCommand(Str_SQL.ToString(), Conn);
            //    cmd.Parameters.AddWithValue("@SN", Str_SN);
            //    cmd.Parameters.AddWithValue("@IDNO", Str_IDNO);
            //    SqlDataAdapter Ada = new SqlDataAdapter(cmd);
            //    DataTable DT = new DataTable();
            //    Ada.Fill(DT);

            //    if (DT.Rows.Count > 0)
            //    {
            //        //不允許 - 引導頁未啟動 ( Guideline == "1" )
            //        if (DT.Rows[0]["Guideline"].ToString().Trim() == "1")
            //        {
            //            return RedirectToAction("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
            //        }
            //        else
            //        {
            //            //未進行銀行核身
            //            if (DT.Rows[0]["eDDA_Account"].ToString().Trim() == "" || DT.Rows[0]["OTP_Time"].ToString().Trim() == "" || DT.Rows[0]["Phone"].ToString().Trim() == "")
            //            {
            //                return RedirectToAction("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
            //            }
            //            else
            //            {
            //                #region ::: 檢測銀行認證OTP是否已失效 :::
            //                if (DT.Rows[0]["ToCRM"].ToString().Trim() != "1")
            //                {
            //                    string[] aryIs24HR = OTP.Is24HR(DT.Rows[0]["OTP_Time"].ToString().Trim());
            //                    if (aryIs24HR[0] != "Y")
            //                    {
            //                        return RedirectToAction("error", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web, @s = "processst", @e = "Expired" });
            //                    }
            //                }
            //                #endregion

            //                if (TimeClass.ValidTime(Str_T, 60))
            //                {
            //                    Str_ReC = Encryption.SetMD5("STCode" + Str_T + Str_IDNO + Str_SN + Str_EnID + "edoCTS");
            //                    if (Str_ReC == Str_C)
            //                    {
            //                        Str_Status = "Y";
            //                        Str_MSG = "驗證成功";
            //                        Str_Code = "";
            //                        Str_URL = Url.Action("GetResult", "API_processst");
            //                    }
            //                    else
            //                    {
            //                        Str_Status = "N";
            //                        Str_MSG = "驗證失敗，請重新再試";
            //                        Str_Code = "E002";
            //                    }
            //                }
            //                else
            //                {
            //                    Str_Status = "N";
            //                    Str_MSG = "驗證碼已失效，請重新再試";
            //                    Str_Code = "E001";
            //                }
            //            }
            //        }
            //    }
            //    else
            //    {
            //        //防止 SN、IDNO 不一致
            //        return RedirectToAction("Index", "Apply", new { @strProd = Str_Prod, @strWeb = Str_Web });
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Str_Exception = ex.ToString();

            //    Str_Status = "N";
            //    Str_MSG = ConfigurationManager.AppSettings["WebSite_ERR_MSG"];
            //    Str_Code = "E003";
            //}

            //ViewBag.Prod = Str_Prod;
            //ViewBag.Web = Str_Web;
            //ViewBag.LoadingOff = (Str_Status == "Y") ? "N" : "Y";//(Y)是、(N)否 關閉 Loading for JS
            //ViewBag.MSG = (Str_Status == "Y") ? "" : Str_MSG;
            //ViewBag.Code = (Str_Status == "Y") ? "" : Str_Code;
            //ViewBag.T = (Str_Status == "Y") ? Str_T : "";
            //ViewBag.C = (Str_Status == "Y") ? Str_C : "";
            //ViewBag.URL = (Str_Status == "Y") ? Str_URL : "";

            //#region ::: Write Log :::

            //Str_Log = new StringBuilder();
            //Str_Log.Append("功能 = 產生(ST)證券開戶契約書 Start" + SetSplit);
            //Str_Log.Append("程式 = ApplyController.cs/processst" + SetSplit);
            //Str_Log.Append("Str_T = " + Str_T + SetSplit);
            //Str_Log.Append("Str_C = " + Str_C + SetSplit);
            //Str_Log.Append("Str_ReC = " + Str_ReC + SetSplit);
            //Str_Log.Append("Str_Status = " + Str_Status + SetSplit);
            //Str_Log.Append("Str_MSG = " + Str_MSG + SetSplit);
            //Str_Log.Append("Str_Code = " + Str_Code + SetSplit);
            //Str_Log.Append("Str_URL = " + Str_URL + SetSplit);
            //if (Str_Exception != "")
            //{
            //    Str_Log.Append(SetSplit + "Exception = " + SetSplit + Str_Exception);
            //}
            //LogClass.SpdOpenAct_Log(Str_Web, Str_IDNO, Str_Log.ToString(), ((Str_Status != "Y" || Str_Exception != "") ? "1" : ""), Str_IP);

            //#endregion

            return View();
        }
        #endregion

       

        #region === 模擬測試 (ST+SUB)證券+複委託開戶契約書 Start ===
        public ActionResult processtest()
        {
            string Str_SN = ((!String.IsNullOrEmpty(Request.QueryString["SN"] as string)) ? SQLInjection.SetValue(Request.QueryString["SN"].ToString().Trim()) : "");

            ViewBag.SN = Str_SN;
            ViewBag.URL = Url.Action("GetResult", "API_processtest");

            return View();
        }
        #endregion

        #region === 模擬測試 (ST+SUB)證券+複委託開戶契約書 End ===
        public ActionResult processtestidpret()
        {
            #region ::: 參數 :::

            //錯誤訊息 標題
            string Str_Title = "開戶文件產製失敗";

            //錯誤訊息
            string Str_MSG = "";

            //錯誤代碼
            string Str_Code = "";

            //接收 POST 過來參數的 驗證碼
            string Str_hashIdentifyInfo = "";

            #endregion

            #region ★★★ 1. 接收 POST 參數 ★★★

            //應用平台代號，預設23113343
            string Str_BusinessNo = ((!String.IsNullOrEmpty(Request["BusinessNo"] as string)) ? SQLInjection.SetValue(Request["BusinessNo"].ToString().Trim()) : "");
            //API版本版號，預設"1.0"
            string Str_ApiVersion = ((!String.IsNullOrEmpty(Request["ApiVersion"] as string)) ? SQLInjection.SetValue(Request["ApiVersion"].ToString().Trim()) : "");
            //HashKey組別，預設"1"
            string Str_HashKeyNo = ((!String.IsNullOrEmpty(Request["HashKeyNo"] as string)) ? SQLInjection.SetValue(Request["HashKeyNo"].ToString().Trim()) : "");
            //驗證編號 ( 需唯一 ) = SN + IDNO + yyyyMMddHHmmss
            string Str_VerifyNo = ((!String.IsNullOrEmpty(Request["VerifyNo"] as string)) ? SQLInjection.SetValue(Request["VerifyNo"].ToString().Trim()) : "");
            //應用平台自訂字串 ( SN_IDNO_yyyyMMddHHmmss )
            string Str_ReturnParams = ((!String.IsNullOrEmpty(Request["ReturnParams"] as string)) ? SQLInjection.SetValue(Request["ReturnParams"].ToString().Trim()) : "");
            //通行證
            string Str_Token = ((!String.IsNullOrEmpty(Request["Token"] as string)) ? SQLInjection.SetValue(Request["Token"].ToString().Trim()) : "");
            //帶空值(身分驗證才會用到)
            string Str_CAType = ((!String.IsNullOrEmpty(Request["CAType"] as string)) ? SQLInjection.SetValue(Request["CAType"].ToString().Trim()) : "");
            //顧客身分證號是否一致：(1)一致、(2)不一致
            string Str_MemberNoMapping = ((!String.IsNullOrEmpty(Request["MemberNoMapping"] as string)) ? SQLInjection.SetValue(Request["MemberNoMapping"].ToString().Trim()) : "");
            //執行結果：(S)執行成功、(F)執行失敗
            string Str_ResultCode = ((!String.IsNullOrEmpty(Request["ResultCode"] as string)) ? SQLInjection.SetValue(Request["ResultCode"].ToString().Trim()) : "");
            //交易結果代碼：(0000)成功
            string Str_ReturnCode = ((!String.IsNullOrEmpty(Request["ReturnCode"] as string)) ? SQLInjection.SetValue(Request["ReturnCode"].ToString().Trim()) : "");
            //結果訊息
            string Str_ReturnCodeDesc = ((!String.IsNullOrEmpty(Request["ReturnCodeDesc"] as string)) ? SQLInjection.SetValue(Request["ReturnCodeDesc"].ToString().Trim()) : "");
            //驗證碼
            string Str_IdentifyNo = ((!String.IsNullOrEmpty(Request["IdentifyNo"] as string)) ? SQLInjection.SetValue(Request["IdentifyNo"].ToString().Trim()) : "");
            //QR PDF DocumentID
            string Str_QRDocumentID = ((!String.IsNullOrEmpty(Request["QRDocumentID"] as string)) ? SQLInjection.SetValue(Request["QRDocumentID"].ToString().Trim()) : "");

            #endregion

            try
            {
                if (Str_ResultCode == "S" && Str_ReturnCode == "0000")
                {
                    //檢查是否同SN、IDNO
                    string[] aryReturnParams = Str_ReturnParams.Split('_');//應用平台自訂字串 ( SN_IDNO_yyyyMMddHHmmss )
                    if (aryReturnParams.Length == 3)
                    {
                        #region ★★★ 2. 複驗IdentifyNo ★★★

                        //驗證碼 - 資訊 ( identifyInfo )
                        StringBuilder Str_identifyInfo = new StringBuilder();
                        Str_identifyInfo.Append(Str_BusinessNo);
                        Str_identifyInfo.Append(Str_ApiVersion);
                        Str_identifyInfo.Append(Str_HashKeyNo);
                        Str_identifyInfo.Append(Str_VerifyNo);
                        Str_identifyInfo.Append(Str_ReturnParams);
                        Str_identifyInfo.Append(Str_Token);
                        Str_identifyInfo.Append(Str_CAType);
                        Str_identifyInfo.Append(Str_MemberNoMapping);
                        Str_identifyInfo.Append(Str_ResultCode);
                        Str_identifyInfo.Append(Str_ReturnCode);
                        Str_identifyInfo.Append("showmethemoney");

                        //驗證碼
                        Str_hashIdentifyInfo = Encryption.hashIdentifyInfo(Str_identifyInfo.ToString());

                        #endregion

                        //複驗 - 驗證碼 IdentifyNo
                        if (Str_hashIdentifyInfo == Str_IdentifyNo)
                        {
                            Str_Title = "ST+SUB開戶文件產製成功";
                            Str_MSG = "<a href='" + ConfigurationManager.AppSettings["WebSite_URL"] + "/QR_Doc_Test?IDNO=" + aryReturnParams[1] + "&D=" + Str_QRDocumentID + "' target='_blank'>下載PDF</a>";
                            Str_Code = "Test Only";
                        }
                        else
                        {
                            //失敗 - 複驗驗證碼 IdentifyNo 不一致
                            Str_Title = "ST+SUB開戶文件產製失敗";
                            Str_MSG = "參數傳遞錯誤";
                            Str_Code = "TWID-E001";
                        }
                    }
                    else
                    {
                        //應用平台自訂字串錯誤
                        Str_Title = "ST+SUB開戶文件產製失敗";
                        Str_MSG = "參數傳遞錯誤";
                        Str_Code = "TWID-E002";
                    }
                }
                else
                {
                    //失敗 - TWID Portal 回傳異常
                    Str_Title = "ST+SUB開戶文件產製失敗";
                    Str_MSG = Str_ReturnCodeDesc;
                    Str_Code = Str_ResultCode + "-" + Str_ReturnCode;
                }
            }
            catch (Exception ex)
            {
                //發生 Exception
                Str_Title = "ST+SUB開戶文件產製失敗";
                Str_MSG = ex.ToString();
                Str_Code = "EX-E001";
            }

            ViewBag.Title = Str_Title;
            ViewBag.MSG = Str_MSG;
            ViewBag.Code = Str_Code;

            return View();
        }
        #endregion

        //----------------------------------------//

        #region === 模擬測試 QR PDF 下載 ===
        public ActionResult QR_Doc_Test()
        {
            try {
                LogClass.WriteLog("API_PDF", "==================QR_Doc_Test===================");
                string Str_IDNO = SQLInjection.SetValue(Request.QueryString["IDNO"]);
                string Str_DocumentID = SQLInjection.SetValue(Request.QueryString["D"]);    //QR PDF 文件識別碼
                string Str_Session = "";                                                    //Session Token

                LogClass.WriteLog("API_PDF", "==================Str_IDNO===================" + Str_IDNO);
                LogClass.WriteLog("API_PDF", "==================Str_DocumentID===================" + Str_DocumentID);

                #region === 登入 QR PDF API ===
                bool bl_Login = false;
                string[] aryLogin = QR_PDF.Login();
                if (aryLogin.Length == 3)
                {
                    string Str_ResultCode = aryLogin[0].ToString().Trim();
                    string Str_FailReason = aryLogin[1].ToString().Trim();
                    Str_Session = aryLogin[2].ToString().Trim();

                    if (Str_ResultCode == "0")
                    {
                        bl_Login = true;
                    }
                }
                #endregion
                LogClass.WriteLog("API_PDF", "==================bl_Login===================" + bl_Login);
                if (bl_Login)
                {

                    #region === 下載 QR PDF API ===

                    string[] aryGetPreviewPDF = QR_PDF.GetPreviewPDF(Str_IDNO, Str_Session, Str_DocumentID, "PDF");
                    //string[] aryGetPreviewPDF = QR_PDF.GetSignedPDF(Str_IDNO, Str_Session, Str_DocumentID, Str_IDNO, "PDF");
                    if (aryGetPreviewPDF.Length == 2)
                    {
                        string Str_ResultCode = aryGetPreviewPDF[0].ToString().Trim();//表示此API的執行結果代碼
                        string Str_FailReason = aryGetPreviewPDF[1].ToString().Trim();//表示此API失敗說明訊息

                        #region === Write Log ===
                        LogClass.WriteLog("API_PDF", "==================Str_ResultCode===================" + Str_ResultCode);
                        LogClass.WriteLog("API_PDF", "==================Str_FailReason===================" + Str_FailReason);
                       
                        #endregion

                        Response.Write(Str_ResultCode + ":" + Str_FailReason);
                    }

                    #endregion

                    ////取得 PDF Stream
                    //WebResponse wr = QR_PDF.GetPreviewPDF(Str_IDNO, Str_Session, Str_DocumentID, "PDF");
                    
                    ////登出PDF
                    //string[] aryLogout = QR_PDF.Logout(Str_Session);
                    //LogClass.WriteLog("API_PDF", "==================wr.ContentType===================" + wr.ContentType);
                    ////if (wr.ContentType == "application/pdf")
                    //{
                    //    Stream stream = wr.GetResponseStream();
                    //    return File(stream, "application/pdf", "PDF.pdf");
                    //}
                }
                

            } catch (Exception ex) {


                LogClass.WriteLog("API_PDF", "==================ex.ToString===================" + ex.ToString());

            }
            LogClass.WriteLog("API_PDF", "==================QR_Doc_Test END===================");
            return RedirectToAction("error", "Apply", new { @s = "QR_Doc_Test", @e = "PDF" });
        }
        #endregion

        #region === QR PDF 下載 ===
        public ActionResult DownloadPDF()
        {
            //Log 分隔字串
            string SetSplit = ConfigurationManager.AppSettings["LogSplit"];

            //Log 字串
            StringBuilder Str_Log = new StringBuilder();

            string Str_Prod = SQLInjection.SetValue(Request.QueryString["P"]);          //行銷代碼 - 專案代碼
            string Str_Web = SQLInjection.SetValue(Request.QueryString["W"]);           //行銷代碼 - 網頁來源代碼
            string Str_PGM = SQLInjection.SetValue(Request.QueryString["M"]);           //來源程式
            string Str_EnID = SQLInjection.SetValue(Request.QueryString["E"]);          //身分證字號(密文)
            string Str_Kind = SQLInjection.SetValue(Request.QueryString["K"]);          //類別：(ST)證券、(SUB)複委託、(STSUB)證券+複委託[二合一]
            string Str_Session = "";                                                    //Session Token
            string Str_DocumentID = SQLInjection.SetValue(Request.QueryString["D"]);    //QR PDF 文件識別碼
            string Str_Time = SQLInjection.SetValue(Request.QueryString["T"]);          //產生時間
            string Str_Code = SQLInjection.SetValue(Request.QueryString["C"]);          //MD5 檢查碼
            string Str_ClientIP = LogClass.GetUserIP();                                 //Client IP
            int MonthDay = 0;                                                           //月日數值(ex: 7月5日 → 705)
            string Str_IDNO = "";                                                       //身分證字號
            string Str_ReCode = "";

            //月日數值(ex: 7月5日 → 705)
            MonthDay = (Numeric.IsNumeric(Str_Time)) ? Convert.ToInt16(Str_Time) : 0;

            //身分證字號
            Str_IDNO = (Encryption.isEnID()) ? Encryption.myDecode(Str_EnID, MonthDay) : Str_EnID;

            string Str_FileName = "";//檔案名稱
            switch (Str_Kind)
            {
                case "ST":
                    Str_FileName = "受託買賣國內有價證券開戶契約總約定書-簡易版";
                    break;
                case "SUB":
                    Str_FileName = "受託買賣外國有價證券開戶契約總約定書-簡易版";
                    break;
                case "STSUB":
                    Str_FileName = "受託買賣國內、外有價證券開戶契約總約定書-簡易版";
                    break;
            }

            if (Str_FileName != "")
            {
                //驗證檢查碼
                Str_ReCode = Encryption.SetMD5(Str_IDNO + "_SpdOpenActDownloadPDF_" + Str_EnID + Str_DocumentID + Str_Time + Str_Prod + Str_Web + Str_Kind + Str_PGM);

                #region :::: Write Log ::::

                Str_Log = new StringBuilder();
                Str_Log.Append("功能 = 下載 QR PDF 接收參數" + SetSplit);
                Str_Log.Append("程式 = DownloadPDF" + SetSplit);
                Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
                Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
                Str_Log.Append("Str_PGM = " + Str_PGM + SetSplit);
                Str_Log.Append("Str_EnID = " + Str_EnID + SetSplit);
                Str_Log.Append("Str_Kind = " + Str_Kind + SetSplit);
                Str_Log.Append("Str_DocumentID = " + Str_DocumentID + SetSplit);
                Str_Log.Append("Str_Time = " + Str_Time + SetSplit);
                Str_Log.Append("Str_Code = " + Str_Code + SetSplit);
                Str_Log.Append("Str_ClientIP = " + Str_ClientIP + SetSplit);
                Str_Log.Append("MonthDay = " + MonthDay + SetSplit);
                Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
                Str_Log.Append("Str_ReCode = " + Str_ReCode);
                LogClass.SpdOpenAct_Log(Str_Web, Str_IDNO, Str_Log.ToString(), ((Str_Code != Str_ReCode) ? "1" : ""), Str_ClientIP);

                #endregion

                //MD5 檢查碼 需一致
                if (Str_Code == Str_ReCode)
                {
                    #region === 登入 QR PDF API ===
                    bool bl_Login = false;
                    string[] aryLogin = QR_PDF.Login();
                    if (aryLogin.Length == 3)
                    {
                        string Str_ResultCode = aryLogin[0].ToString().Trim();
                        string Str_FailReason = aryLogin[1].ToString().Trim();
                        Str_Session = aryLogin[2].ToString().Trim();

                        if (Str_ResultCode == "0")
                        {
                            bl_Login = true;
                        }
                    }
                    #endregion

                    if (bl_Login)
                    {
                        //取得 PDF Stream
                        WebResponse wr = QR_PDF.DownloadPDF(Str_IDNO, Str_Session, Str_DocumentID);

                        //登出PDF
                        string[] aryLogout = QR_PDF.Logout(Str_Session);

                        if (wr.ContentType == "application/pdf")
                        {
                            //下載 QR PDF 寫 Log
                            PDFWriteLog("1", Str_Prod, Str_Web, Str_PGM, Str_IDNO, Str_Kind, Str_DocumentID, Str_ClientIP);

                            Stream stream = wr.GetResponseStream();
                            return File(stream, "application/pdf", ((BrowserDevice.CheckIE()) ? HttpUtility.UrlEncode(Str_FileName, System.Text.Encoding.UTF8) : Str_FileName) + ".pdf");
                        }
                        else
                        {
                            //下載 QR PDF 寫 Log
                            PDFWriteLog("0", Str_Prod, Str_Web, Str_PGM, Str_IDNO, Str_Kind, Str_DocumentID, Str_ClientIP);

                            #region :::: Write Log ::::

                            Str_Log = new StringBuilder();
                            Str_Log.Append("功能 = 下載 QR PDF 失敗(1)" + SetSplit);
                            Str_Log.Append("程式 = DownloadPDF" + SetSplit);
                            Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
                            Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
                            Str_Log.Append("Str_PGM = " + Str_PGM + SetSplit);
                            Str_Log.Append("Str_EnID = " + Str_EnID + SetSplit);
                            Str_Log.Append("Str_Kind = " + Str_Kind + SetSplit);
                            Str_Log.Append("Str_DocumentID = " + Str_DocumentID + SetSplit);
                            Str_Log.Append("Str_Time = " + Str_Time + SetSplit);
                            Str_Log.Append("Str_Code = " + Str_Code + SetSplit);
                            Str_Log.Append("Str_ClientIP = " + Str_ClientIP + SetSplit);
                            Str_Log.Append("MonthDay = " + MonthDay + SetSplit);
                            Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
                            Str_Log.Append("Str_ReCode = " + Str_ReCode);
                            LogClass.SpdOpenAct_Log(Str_Web, Str_IDNO, Str_Log.ToString(), "1", Str_ClientIP);

                            #endregion

                            return RedirectToAction("error", "Apply", new { @s = "DownloadPDF", @e = "PDF_" + Str_Kind });
                        }
                    }
                    else
                    {
                        //下載 QR PDF 寫 Log
                        PDFWriteLog("0", Str_Prod, Str_Web, Str_PGM, Str_IDNO, Str_Kind, Str_DocumentID, Str_ClientIP);

                        #region :::: Write Log ::::

                        Str_Log = new StringBuilder();
                        Str_Log.Append("功能 = 下載 QR PDF 失敗(2)" + SetSplit);
                        Str_Log.Append("程式 = DownloadPDF" + SetSplit);
                        Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
                        Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
                        Str_Log.Append("Str_PGM = " + Str_PGM + SetSplit);
                        Str_Log.Append("Str_EnID = " + Str_EnID + SetSplit);
                        Str_Log.Append("Str_Kind = " + Str_Kind + SetSplit);
                        Str_Log.Append("Str_DocumentID = " + Str_DocumentID + SetSplit);
                        Str_Log.Append("Str_Time = " + Str_Time + SetSplit);
                        Str_Log.Append("Str_Code = " + Str_Code + SetSplit);
                        Str_Log.Append("Str_ClientIP = " + Str_ClientIP + SetSplit);
                        Str_Log.Append("MonthDay = " + MonthDay + SetSplit);
                        Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
                        Str_Log.Append("Str_ReCode = " + Str_ReCode);
                        LogClass.SpdOpenAct_Log(Str_Web, Str_IDNO, Str_Log.ToString(), "1", Str_ClientIP);

                        #endregion

                        return RedirectToAction("error", "Apply", new { @s = "DownloadPDF", @e = "PDF_" + Str_Kind });
                    }
                }
                else
                {
                    //下載 QR PDF 寫 Log
                    PDFWriteLog("0", Str_Prod, Str_Web, Str_PGM, Str_IDNO, Str_Kind, Str_DocumentID, Str_ClientIP);

                    #region :::: Write Log ::::

                    Str_Log = new StringBuilder();
                    Str_Log.Append("功能 = 下載 QR PDF 失敗(3)" + SetSplit);
                    Str_Log.Append("程式 = DownloadPDF" + SetSplit);
                    Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
                    Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
                    Str_Log.Append("Str_PGM = " + Str_PGM + SetSplit);
                    Str_Log.Append("Str_EnID = " + Str_EnID + SetSplit);
                    Str_Log.Append("Str_Kind = " + Str_Kind + SetSplit);
                    Str_Log.Append("Str_DocumentID = " + Str_DocumentID + SetSplit);
                    Str_Log.Append("Str_Time = " + Str_Time + SetSplit);
                    Str_Log.Append("Str_Code = " + Str_Code + SetSplit);
                    Str_Log.Append("Str_ClientIP = " + Str_ClientIP + SetSplit);
                    Str_Log.Append("MonthDay = " + MonthDay + SetSplit);
                    Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
                    Str_Log.Append("Str_ReCode = " + Str_ReCode);
                    LogClass.SpdOpenAct_Log(Str_Web, Str_IDNO, Str_Log.ToString(), "1", Str_ClientIP);

                    #endregion

                    return RedirectToAction("error", "Apply", new { @s = "DownloadPDF", @e = "PDF_" + Str_Kind });
                }
            }
            else
            {
                //下載 QR PDF 寫 Log
                PDFWriteLog("0", Str_Prod, Str_Web, Str_PGM, Str_IDNO, Str_Kind, Str_DocumentID, Str_ClientIP);

                #region :::: Write Log ::::

                Str_Log = new StringBuilder();
                Str_Log.Append("功能 = 下載 QR PDF 接收參數有誤" + SetSplit);
                Str_Log.Append("程式 = DownloadPDF" + SetSplit);
                Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
                Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
                Str_Log.Append("Str_PGM = " + Str_PGM + SetSplit);
                Str_Log.Append("Str_EnID = " + Str_EnID + SetSplit);
                Str_Log.Append("Str_Kind = " + Str_Kind + SetSplit);
                Str_Log.Append("Str_DocumentID = " + Str_DocumentID + SetSplit);
                Str_Log.Append("Str_Time = " + Str_Time + SetSplit);
                Str_Log.Append("Str_Code = " + Str_Code + SetSplit);
                Str_Log.Append("Str_ClientIP = " + Str_ClientIP + SetSplit);
                Str_Log.Append("MonthDay = " + MonthDay + SetSplit);
                Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
                Str_Log.Append("Str_ReCode = " + Str_ReCode);
                LogClass.SpdOpenAct_Log(Str_Web, Str_IDNO, Str_Log.ToString(), "1", Str_ClientIP);

                #endregion

                //sponse.Write("參數傳遞錯誤");
                return RedirectToAction("error", "Apply", new { @s = "DownloadPDF", @e = "PDF_Kind" });
            }
        }

        #region === 下載 QR PDF 寫 Log ===
        /// <summary>
        /// 下載 QR PDF 寫 Log
        /// </summary>
        /// <param name="Str_Status">狀態：(1)成功、(0)失敗</param>
        /// <param name="Str_IDNO">身分證字號</param>
        /// <param name="Str_Kind">類別：(ST)證券、(SUB)複委託、(STSUB)證券+複委託[二合一]</param>
        /// <param name="Str_DocumentID">QR PDF 文件識別碼</param>
        /// <param name="Str_ClientIP">Client IP</param>
        protected void PDFWriteLog(string Str_Status,
            string Str_Prod, string Str_Web,
            string Str_PGM,
            string Str_IDNO, string Str_Kind, string Str_DocumentID, string Str_ClientIP)
        {
            //Server IP
            string Str_ServerIP = ConfigurationManager.AppSettings["Server_IP"].ToString();

            //UserAgent
            string Str_UserAgent = System.Web.HttpContext.Current.Request.UserAgent;
            string Str_Device = BrowserDevice.GetDevice(Str_UserAgent);
            string Str_Browser = BrowserDevice.GetBrowser();

            try
            {
                SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SCM"].ToString());
                StringBuilder Str_SQL = new StringBuilder();
                Str_SQL.Append("INSERT INTO SpdOpenAct_PDF ");
                Str_SQL.Append("(Status,strProd,strWeb,PGM,IDNO,Kind,DocumentID,Device,Browser,UserAgent,ServerIP,ClientIP) VALUES ");
                Str_SQL.Append("(@Status,@strProd,@strWeb,@PGM,@IDNO,@Kind,@DocumentID,@Device,@Browser,@UserAgent,@ServerIP,@ClientIP); ");
                SqlCommand cmd = new SqlCommand(Str_SQL.ToString(), Conn);
                cmd.Parameters.AddWithValue("@Status", Str_Status);
                cmd.Parameters.AddWithValue("@strProd", Str_Prod);
                cmd.Parameters.AddWithValue("@strWeb", Str_Web);
                cmd.Parameters.AddWithValue("@PGM", Str_PGM);
                cmd.Parameters.AddWithValue("@IDNO", Str_IDNO);
                cmd.Parameters.AddWithValue("@Kind", Str_Kind);
                cmd.Parameters.AddWithValue("@DocumentID", Str_DocumentID);
                cmd.Parameters.AddWithValue("@Device", Str_Device);
                cmd.Parameters.AddWithValue("@Browser", Str_Browser);
                cmd.Parameters.AddWithValue("@UserAgent", Str_UserAgent);
                cmd.Parameters.AddWithValue("@ServerIP", Str_ServerIP);
                cmd.Parameters.AddWithValue("@ClientIP", Str_ClientIP);
                SqlDataAdapter Ada = new SqlDataAdapter(cmd);
                DataTable DT = new DataTable();
                Ada.Fill(DT);
            }
            catch (Exception ex)
            {
                #region === Write Log ===

                //Log 分隔字串
                string SetSplit = ConfigurationManager.AppSettings["LogSplit"];

                StringBuilder Str_Log = new StringBuilder();
                Str_Log.Append("功能 = 下載 QR PDF 寫 Log" + SetSplit);
                Str_Log.Append("程式 = DownloadPDF/PDFWriteLog" + SetSplit);
                Str_Log.Append("Str_Status = " + Str_Status + SetSplit);
                Str_Log.Append("Str_Prod = " + Str_Prod + SetSplit);
                Str_Log.Append("Str_Web = " + Str_Web + SetSplit);
                Str_Log.Append("Str_PGM = " + Str_PGM + SetSplit);
                Str_Log.Append("Str_IDNO = " + Str_IDNO + SetSplit);
                Str_Log.Append("Str_Kind = " + Str_Kind + SetSplit);
                Str_Log.Append("Str_DocumentID = " + Str_DocumentID + SetSplit);
                Str_Log.Append("Str_Device = " + Str_Device + SetSplit);
                Str_Log.Append("Str_Browser = " + Str_Browser + SetSplit);
                Str_Log.Append("Str_UserAgent = " + Str_UserAgent + SetSplit);
                Str_Log.Append("Str_ServerIP = " + Str_ServerIP + SetSplit);
                Str_Log.Append("Str_ClientIP = " + Str_ClientIP + SetSplit);
                Str_Log.Append("Exception = " + SetSplit + ex.ToString());
                LogClass.WriteLog("DownloadPDF", Str_Log.ToString());

                #endregion
            }
        }
        #endregion

        #endregion

       
        
    }
}